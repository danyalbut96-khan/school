<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['parent']);

$pageTitle = "Fee Records";
require_once '../includes/header.php';

$user_id = $_SESSION['user_id'];
$parent = $db->query("SELECT p.*, s.id as student_db_id FROM parents p JOIN students s ON p.student_id = s.id WHERE p.user_id = $user_id")->fetch_assoc();
$student_id = $parent['student_db_id'];

// Get fee records
$result = $db->query("SELECT * FROM fees WHERE student_id = $student_id ORDER BY due_date DESC");
$fees = [];
while ($row = $result->fetch_assoc()) {
    $fees[] = $row;
}

// Calculate totals
$total_due = 0;
$total_paid = 0;
foreach ($fees as $fee) {
    $total_due += $fee['amount'];
    $total_paid += $fee['paid_amount'];
}
$total_pending = $total_due - $total_paid;
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> Child's Attendance</a></li>
                    <li><a href="grades.php"><i class="fas fa-chart-line"></i> Child's Grades</a></li>
                    <li><a href="fees.php" class="active"><i class="fas fa-money-bill-wave"></i> Fee Records</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Fee Records</h2>

            <!-- Summary Cards -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number">$<?php echo number_format($total_due, 2); ?></div>
                                <div class="stat-label">Total Due</div>
                            </div>
                            <div class="stat-icon primary">
                                <i class="fas fa-dollar-sign"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number">$<?php echo number_format($total_paid, 2); ?></div>
                                <div class="stat-label">Total Paid</div>
                            </div>
                            <div class="stat-icon success">
                                <i class="fas fa-check-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number">$<?php echo number_format($total_pending, 2); ?></div>
                                <div class="stat-label">Pending</div>
                            </div>
                            <div class="stat-icon danger">
                                <i class="fas fa-exclamation-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Fee History</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Fee Type</th>
                                    <th>Amount</th>
                                    <th>Paid</th>
                                    <th>Due Date</th>
                                    <th>Payment Date</th>
                                    <th>Status</th>
                                    <th>Receipt</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($fees)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No fee records found</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($fees as $fee): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($fee['fee_type']); ?></td>
                                            <td>$<?php echo number_format($fee['amount'], 2); ?></td>
                                            <td>$<?php echo number_format($fee['paid_amount'], 2); ?></td>
                                            <td><?php echo formatDate($fee['due_date']); ?></td>
                                            <td><?php echo $fee['payment_date'] ? formatDate($fee['payment_date']) : 'N/A'; ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $fee['status'] == 'paid' ? 'success' : 
                                                        ($fee['status'] == 'partial' ? 'warning' : 'danger'); 
                                                ?>">
                                                    <?php echo ucfirst($fee['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($fee['receipt_number']): ?>
                                                    <?php echo htmlspecialchars($fee['receipt_number']); ?>
                                                <?php else: ?>
                                                    N/A
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

