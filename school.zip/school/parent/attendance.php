<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['parent']);

$pageTitle = "Child's Attendance";
require_once '../includes/header.php';

$user_id = $_SESSION['user_id'];
$parent = $db->query("SELECT p.*, s.id as student_db_id FROM parents p JOIN students s ON p.student_id = s.id WHERE p.user_id = $user_id")->fetch_assoc();
$student_id = $parent['student_db_id'];

$month = $_GET['month'] ?? date('Y-m');
$start_date = $month . '-01';
$end_date = date('Y-m-t', strtotime($start_date));

// Get attendance records
$result = $db->query("SELECT a.*, s.subject_name FROM attendance a LEFT JOIN subjects s ON a.subject_id = s.id WHERE a.student_id = $student_id AND a.date BETWEEN '$start_date' AND '$end_date' ORDER BY a.date DESC");
$attendance = [];
while ($row = $result->fetch_assoc()) {
    $attendance[] = $row;
}

// Calculate statistics
$total_days = count($attendance);
$present = count(array_filter($attendance, function($a) { return $a['status'] == 'present'; }));
$absent = count(array_filter($attendance, function($a) { return $a['status'] == 'absent'; }));
$late = count(array_filter($attendance, function($a) { return $a['status'] == 'late'; }));
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="attendance.php" class="active"><i class="fas fa-calendar-check"></i> Child's Attendance</a></li>
                    <li><a href="grades.php"><i class="fas fa-chart-line"></i> Child's Grades</a></li>
                    <li><a href="fees.php"><i class="fas fa-money-bill-wave"></i> Fee Records</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Child's Attendance</h2>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Select Month</h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="">
                        <input type="month" class="form-control" name="month" value="<?php echo $month; ?>" onchange="this.form.submit()">
                    </form>
                </div>
            </div>

            <!-- Statistics -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="stat-card text-center">
                        <div class="stat-number text-primary"><?php echo $present; ?></div>
                        <div class="stat-label">Present</div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card text-center">
                        <div class="stat-number text-danger"><?php echo $absent; ?></div>
                        <div class="stat-label">Absent</div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card text-center">
                        <div class="stat-number text-warning"><?php echo $late; ?></div>
                        <div class="stat-label">Late</div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card text-center">
                        <div class="stat-number"><?php echo $total_days > 0 ? round(($present / $total_days) * 100) : 0; ?>%</div>
                        <div class="stat-label">Attendance Rate</div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Attendance Records</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Subject</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($attendance)): ?>
                                    <tr>
                                        <td colspan="3" class="text-center">No attendance records found</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($attendance as $record): ?>
                                        <tr>
                                            <td><?php echo formatDate($record['date']); ?></td>
                                            <td><?php echo htmlspecialchars($record['subject_name'] ?? 'General'); ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $record['status'] == 'present' ? 'success' : 
                                                        ($record['status'] == 'late' ? 'warning' : 
                                                        ($record['status'] == 'excused' ? 'info' : 'danger')); 
                                                ?>">
                                                    <?php echo ucfirst($record['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

