<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['parent']);

$pageTitle = "Parent Dashboard";
require_once '../includes/header.php';

$user_id = $_SESSION['user_id'];
$parent = $db->query("SELECT p.*, s.full_name as student_name, s.student_id, c.class_name, c.section FROM parents p JOIN students s ON p.student_id = s.id LEFT JOIN classes c ON s.class_id = c.id WHERE p.user_id = $user_id")->fetch_assoc();

if (!$parent) {
    setFlashMessage('danger', 'Parent profile not found');
    redirect('../logout.php');
}

$student_id = $parent['student_id'];

// Get statistics
$stats = [];

// Child's Attendance (this month)
$result = $db->query("SELECT COUNT(*) as count FROM attendance WHERE student_id = $student_id AND MONTH(date) = MONTH(CURRENT_DATE()) AND status = 'present'");
$stats['present'] = $result->fetch_assoc()['count'];

$result = $db->query("SELECT COUNT(*) as count FROM attendance WHERE student_id = $student_id AND MONTH(date) = MONTH(CURRENT_DATE())");
$stats['total'] = $result->fetch_assoc()['count'];
$stats['attendance_percent'] = $stats['total'] > 0 ? round(($stats['present'] / $stats['total']) * 100) : 0;

// Pending Fees
$result = $db->query("SELECT SUM(amount - paid_amount) as total FROM fees WHERE student_id = $student_id AND status != 'paid'");
$stats['pending_fees'] = $result->fetch_assoc()['total'] ?? 0;

// Recent Grades
$result = $db->query("SELECT m.*, e.exam_name, s.subject_name FROM marks m JOIN examinations e ON m.examination_id = e.id JOIN subjects s ON m.subject_id = s.id WHERE m.student_id = $student_id ORDER BY m.created_at DESC LIMIT 5");
$recent_grades = [];
while ($row = $result->fetch_assoc()) {
    $recent_grades[] = $row;
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> Child's Attendance</a></li>
                    <li><a href="grades.php"><i class="fas fa-chart-line"></i> Child's Grades</a></li>
                    <li><a href="fees.php"><i class="fas fa-money-bill-wave"></i> Fee Records</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Welcome, <?php echo htmlspecialchars($parent['full_name']); ?></h2>
            <p class="text-muted">Viewing progress for: <strong><?php echo htmlspecialchars($parent['student_name']); ?></strong> (<?php echo htmlspecialchars($parent['class_name'] . ' ' . ($parent['section'] ?? '')); ?>)</p>

            <!-- Statistics Cards -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo $stats['attendance_percent']; ?>%</div>
                                <div class="stat-label">Attendance This Month</div>
                            </div>
                            <div class="stat-icon primary">
                                <i class="fas fa-calendar-check"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number">$<?php echo number_format($stats['pending_fees'], 2); ?></div>
                                <div class="stat-label">Pending Fees</div>
                            </div>
                            <div class="stat-icon danger">
                                <i class="fas fa-money-bill-wave"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo count($recent_grades); ?></div>
                                <div class="stat-label">Recent Grades</div>
                            </div>
                            <div class="stat-icon success">
                                <i class="fas fa-chart-line"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Grades -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-chart-line"></i> Recent Grades</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($recent_grades)): ?>
                        <p class="text-muted">No grades available yet.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Exam</th>
                                        <th>Subject</th>
                                        <th>Marks</th>
                                        <th>Grade</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_grades as $grade): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($grade['exam_name']); ?></td>
                                            <td><?php echo htmlspecialchars($grade['subject_name']); ?></td>
                                            <td><?php echo $grade['marks_obtained']; ?></td>
                                            <td><span class="badge bg-success"><?php echo htmlspecialchars($grade['grade'] ?? 'N/A'); ?></span></td>
                                            <td><?php echo formatDate($grade['created_at']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                    <a href="grades.php" class="btn btn-primary mt-3">View All Grades</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

