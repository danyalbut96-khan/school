<?php
require_once 'config/database.php';
require_once 'config/functions.php';

if (isLoggedIn() && $_SESSION['role'] === 'teacher') {
    redirect('teacher/dashboard.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Please provide both username/email and password.';
    } else {
        $stmt = $db->prepare("SELECT u.id, u.username, u.email, u.password, u.role, t.id AS teacher_id FROM users u JOIN teachers t ON u.id = t.user_id WHERE (u.username = ? OR u.email = ?) AND u.role = 'teacher' LIMIT 1");
        $stmt->bind_param('ss', $username, $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (verifyPassword($password, $user['password'])) {
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['teacher_id'] = $user['teacher_id'];
                $_SESSION['login_time'] = time();
                redirect('teacher/dashboard.php');
            }
        }
        $error = 'Invalid teacher credentials. Please try again.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Login - Smart School</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #0f766e, #10b981);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', sans-serif;
        }
        .login-card {
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 20px 45px rgba(15, 118, 110, 0.35);
            width: 100%;
            max-width: 420px;
            padding: 40px;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="text-center mb-4">
            <div class="d-inline-flex align-items-center justify-content-center bg-success text-white rounded-circle" style="width: 72px; height: 72px;">
                <i class="fas fa-chalkboard-teacher fa-2x"></i>
            </div>
            <h3 class="mt-3 fw-semibold">Teacher Login</h3>
            <p class="text-muted mb-0">Access your classes, assignments, and attendance tools.</p>
        </div>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">Username or Email</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                    <input type="text" class="form-control" name="username" placeholder="Enter username or email" required>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    <input type="password" class="form-control" name="password" placeholder="Enter password" required>
                </div>
            </div>
            <button type="submit" class="btn btn-success w-100">Login as Teacher</button>
        </form>

        <div class="mt-4 text-center">
            <small class="text-muted">Need a different portal? <a href="index.php">Return to home</a></small>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


