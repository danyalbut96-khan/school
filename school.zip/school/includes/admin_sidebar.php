<?php
if (!isset($activePage)) {
    $activePage = '';
}

$menuItems = [
    'dashboard' => ['label' => 'Dashboard', 'icon' => 'fas fa-home', 'link' => 'dashboard.php'],
    'students' => ['label' => 'Students', 'icon' => 'fas fa-user-graduate', 'link' => 'students.php'],
    'parents' => ['label' => 'Parents', 'icon' => 'fas fa-people-roof', 'link' => 'parents.php'],
    'teachers' => ['label' => 'Teachers', 'icon' => 'fas fa-chalkboard-teacher', 'link' => 'teachers.php'],
    'classes' => ['label' => 'Classes', 'icon' => 'fas fa-school', 'link' => 'classes.php'],
    'subjects' => ['label' => 'Subjects', 'icon' => 'fas fa-book', 'link' => 'subjects.php'],
    'examinations' => ['label' => 'Examinations', 'icon' => 'fas fa-clipboard-list', 'link' => 'examinations.php'],
    'attendance' => ['label' => 'Attendance', 'icon' => 'fas fa-calendar-check', 'link' => 'attendance.php'],
    'fees' => ['label' => 'Fees', 'icon' => 'fas fa-money-bill-wave', 'link' => 'fees.php'],
    'salaries' => ['label' => 'Salaries', 'icon' => 'fas fa-wallet', 'link' => 'salaries.php'],
    'notices' => ['label' => 'Notices', 'icon' => 'fas fa-bullhorn', 'link' => 'notices.php'],
    'settings' => ['label' => 'Settings', 'icon' => 'fas fa-cog', 'link' => 'settings.php'],
    'profile' => ['label' => 'Profile', 'icon' => 'fas fa-user-circle', 'link' => 'profile.php'],
];
?>

<div class="sidebar">
    <ul class="sidebar-menu">
        <?php foreach ($menuItems as $key => $item): ?>
            <li>
                <a href="<?php echo $item['link']; ?>" class="<?php echo $activePage === $key ? 'active' : ''; ?>">
                    <i class="<?php echo $item['icon']; ?>"></i> <?php echo $item['label']; ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>

