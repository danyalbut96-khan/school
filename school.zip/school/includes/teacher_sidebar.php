<?php
if (!isset($teacherActivePage)) {
    $teacherActivePage = '';
}

$teacherMenuItems = [
    'dashboard' => ['label' => 'Dashboard', 'icon' => 'fas fa-home', 'link' => 'dashboard.php'],
    'attendance' => ['label' => 'Take Attendance', 'icon' => 'fas fa-calendar-check', 'link' => 'attendance.php'],
    'examinations' => ['label' => 'Examinations', 'icon' => 'fas fa-clipboard-check', 'link' => 'examinations.php'],
    'marks' => ['label' => 'Upload Marks', 'icon' => 'fas fa-graduation-cap', 'link' => 'marks.php'],
    'homework' => ['label' => 'Homework', 'icon' => 'fas fa-book-reader', 'link' => 'homework.php'],
    'schedule' => ['label' => 'Schedule', 'icon' => 'fas fa-calendar-alt', 'link' => 'schedule.php'],
    'profile' => ['label' => 'Profile', 'icon' => 'fas fa-user-circle', 'link' => 'profile.php'],
];
?>

<div class="sidebar">
    <ul class="sidebar-menu">
        <?php foreach ($teacherMenuItems as $key => $item): ?>
            <li>
                <a href="<?php echo $item['link']; ?>" class="<?php echo $teacherActivePage === $key ? 'active' : ''; ?>">
                    <i class="<?php echo $item['icon']; ?>"></i> <?php echo $item['label']; ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>

