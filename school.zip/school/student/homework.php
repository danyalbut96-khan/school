<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['student']);

$pageTitle = "Homework";
require_once '../includes/header.php';

$user_id = $_SESSION['user_id'];
$student = $db->query("SELECT s.* FROM students s WHERE s.user_id = $user_id")->fetch_assoc();
$student_id = $student['id'];

// Get homework for student's class
$result = $db->query("SELECT h.*, s.subject_name, t.full_name as teacher_name FROM homework h JOIN subjects s ON h.subject_id = s.id JOIN teachers t ON h.teacher_id = t.id WHERE h.class_id = {$student['class_id']} ORDER BY h.due_date DESC");
$homework = [];
while ($row = $result->fetch_assoc()) {
    // Check if submitted
    $submission = $db->query("SELECT * FROM homework_submissions WHERE homework_id = {$row['id']} AND student_id = $student_id")->fetch_assoc();
    $row['submission'] = $submission;
    $homework[] = $row;
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> My Attendance</a></li>
                    <li><a href="grades.php"><i class="fas fa-chart-line"></i> My Grades</a></li>
                    <li><a href="homework.php" class="active"><i class="fas fa-book-reader"></i> Homework</a></li>
                    <li><a href="notices.php"><i class="fas fa-bullhorn"></i> Notices</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">My Homework</h2>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Assignments</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($homework)): ?>
                        <p class="text-muted">No homework assigned yet.</p>
                    <?php else: ?>
                        <div class="list-group">
                            <?php foreach ($homework as $hw): ?>
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h5><?php echo htmlspecialchars($hw['title']); ?></h5>
                                            <p class="mb-1"><?php echo nl2br(htmlspecialchars($hw['description'])); ?></p>
                                            <small class="text-muted">
                                                Subject: <?php echo htmlspecialchars($hw['subject_name']); ?> | 
                                                Teacher: <?php echo htmlspecialchars($hw['teacher_name']); ?> | 
                                                Due Date: <?php echo formatDate($hw['due_date']); ?>
                                            </small>
                                            <?php if ($hw['submission']): ?>
                                                <div class="mt-2">
                                                    <span class="badge bg-success">Submitted</span>
                                                    <?php if ($hw['submission']['marks']): ?>
                                                        <span class="badge bg-info">Marks: <?php echo $hw['submission']['marks']; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            <?php else: ?>
                                                <div class="mt-2">
                                                    <span class="badge bg-warning">Pending</span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

