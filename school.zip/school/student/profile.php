<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['student']);

$pageTitle = "Profile";
require_once '../includes/header.php';

$user_id = $_SESSION['user_id'];
$student = $db->query("SELECT s.*, u.username, u.email FROM students s JOIN users u ON s.user_id = u.id WHERE s.user_id = $user_id")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = sanitize($_POST['username']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $phone = sanitize($_POST['phone']);
    $address = sanitize($_POST['address']);

    if (!empty($password)) {
        $hashed_password = hashPassword($password);
        $db->query("UPDATE users SET username = '$username', email = '$email', password = '$hashed_password' WHERE id = $user_id");
    } else {
        $db->query("UPDATE users SET username = '$username', email = '$email' WHERE id = $user_id");
    }

    $db->query("UPDATE students SET phone = '$phone', address = '$address' WHERE user_id = $user_id");

    setFlashMessage('success', 'Profile updated successfully');
    redirect('profile.php');
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> My Attendance</a></li>
                    <li><a href="grades.php"><i class="fas fa-chart-line"></i> My Grades</a></li>
                    <li><a href="homework.php"><i class="fas fa-book-reader"></i> Homework</a></li>
                    <li><a href="notices.php"><i class="fas fa-bullhorn"></i> Notices</a></li>
                    <li><a href="profile.php" class="active"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">My Profile</h2>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Profile Information</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Username *</label>
                                <input type="text" class="form-control" name="username" value="<?php echo htmlspecialchars($student['username']); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email *</label>
                                <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($student['email']); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Password (leave blank to keep current)</label>
                                <input type="password" class="form-control" name="password">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Student ID</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($student['student_id']); ?>" disabled>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Full Name</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($student['full_name']); ?>" disabled>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone</label>
                                <input type="text" class="form-control" name="phone" value="<?php echo htmlspecialchars($student['phone'] ?? ''); ?>">
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Address</label>
                                <textarea class="form-control" name="address" rows="3"><?php echo htmlspecialchars($student['address'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update Profile
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

