<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['student']);

$pageTitle = "My Grades";
require_once '../includes/header.php';

$user_id = $_SESSION['user_id'];
$student = $db->query("SELECT s.* FROM students s WHERE s.user_id = $user_id")->fetch_assoc();
$student_id = $student['id'];

// Get all marks
$result = $db->query("SELECT m.*, e.exam_name, e.exam_type, e.total_marks, s.subject_name FROM marks m JOIN examinations e ON m.examination_id = e.id JOIN subjects s ON m.subject_id = s.id WHERE m.student_id = $student_id ORDER BY e.created_at DESC, s.subject_name");
$grades = [];
while ($row = $result->fetch_assoc()) {
    $grades[] = $row;
}

// Group by exam
$exams = [];
foreach ($grades as $grade) {
    $exam_name = $grade['exam_name'];
    if (!isset($exams[$exam_name])) {
        $exams[$exam_name] = [];
    }
    $exams[$exam_name][] = $grade;
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> My Attendance</a></li>
                    <li><a href="grades.php" class="active"><i class="fas fa-chart-line"></i> My Grades</a></li>
                    <li><a href="homework.php"><i class="fas fa-book-reader"></i> Homework</a></li>
                    <li><a href="notices.php"><i class="fas fa-bullhorn"></i> Notices</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">My Grades</h2>

            <?php if (empty($grades)): ?>
                <div class="alert alert-info">No grades available yet.</div>
            <?php else: ?>
                <?php foreach ($exams as $exam_name => $exam_grades): ?>
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0"><?php echo htmlspecialchars($exam_name); ?></h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Subject</th>
                                            <th>Marks Obtained</th>
                                            <th>Total Marks</th>
                                            <th>Percentage</th>
                                            <th>Grade</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $total_obtained = 0;
                                        $total_max = 0;
                                        foreach ($exam_grades as $grade): 
                                            $total_obtained += $grade['marks_obtained'];
                                            $total_max += $grade['total_marks'];
                                            $percentage = $grade['total_marks'] > 0 ? round(($grade['marks_obtained'] / $grade['total_marks']) * 100, 2) : 0;
                                        ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($grade['subject_name']); ?></td>
                                                <td><?php echo $grade['marks_obtained']; ?></td>
                                                <td><?php echo $grade['total_marks']; ?></td>
                                                <td><?php echo $percentage; ?>%</td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo in_array($grade['grade'], ['A+', 'A']) ? 'success' : 
                                                            (in_array($grade['grade'], ['B', 'C']) ? 'warning' : 'danger'); 
                                                    ?>">
                                                        <?php echo htmlspecialchars($grade['grade']); ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        <tr class="table-info">
                                            <td><strong>Total</strong></td>
                                            <td><strong><?php echo $total_obtained; ?></strong></td>
                                            <td><strong><?php echo $total_max; ?></strong></td>
                                            <td><strong><?php echo $total_max > 0 ? round(($total_obtained / $total_max) * 100, 2) : 0; ?>%</strong></td>
                                            <td></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

