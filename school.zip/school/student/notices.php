<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['student']);

$pageTitle = "Notices";
require_once '../includes/header.php';

// Get notices for students
$result = $db->query("SELECT n.*, u.username FROM notices n JOIN users u ON n.created_by = u.id WHERE n.target_audience IN ('all', 'students') ORDER BY n.created_at DESC");
$notices = [];
while ($row = $result->fetch_assoc()) {
    $notices[] = $row;
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> My Attendance</a></li>
                    <li><a href="grades.php"><i class="fas fa-chart-line"></i> My Grades</a></li>
                    <li><a href="homework.php"><i class="fas fa-book-reader"></i> Homework</a></li>
                    <li><a href="notices.php" class="active"><i class="fas fa-bullhorn"></i> Notices</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Notices & Announcements</h2>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">All Notices</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($notices)): ?>
                        <p class="text-muted">No notices available.</p>
                    <?php else: ?>
                        <div class="list-group">
                            <?php foreach ($notices as $notice): ?>
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h5><?php echo htmlspecialchars($notice['title']); ?></h5>
                                            <p class="mb-1"><?php echo nl2br(htmlspecialchars($notice['content'])); ?></p>
                                            <small class="text-muted">
                                                Posted by <?php echo htmlspecialchars($notice['username']); ?> on <?php echo formatDateTime($notice['created_at']); ?>
                                            </small>
                                        </div>
                                        <div>
                                            <span class="badge bg-<?php echo $notice['priority'] == 'high' ? 'danger' : ($notice['priority'] == 'medium' ? 'warning' : 'info'); ?>">
                                                <?php echo ucfirst($notice['priority']); ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

