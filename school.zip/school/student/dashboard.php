<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['student']);

$pageTitle = "Student Dashboard";
require_once '../includes/header.php';

$user_id = $_SESSION['user_id'];
$student = $db->query("SELECT s.*, c.class_name, c.section FROM students s LEFT JOIN classes c ON s.class_id = c.id WHERE s.user_id = $user_id")->fetch_assoc();

if (!$student) {
    setFlashMessage('danger', 'Student profile not found');
    redirect('../logout.php');
}

$student_id = $student['id'];

// Get statistics
$stats = [];

// Total Attendance (this month)
$result = $db->query("SELECT COUNT(*) as count FROM attendance WHERE student_id = $student_id AND MONTH(date) = MONTH(CURRENT_DATE()) AND status = 'present'");
$stats['present'] = $result->fetch_assoc()['count'];

$result = $db->query("SELECT COUNT(*) as count FROM attendance WHERE student_id = $student_id AND MONTH(date) = MONTH(CURRENT_DATE())");
$stats['total'] = $result->fetch_assoc()['count'];
$stats['attendance_percent'] = $stats['total'] > 0 ? round(($stats['present'] / $stats['total']) * 100) : 0;

// Pending Homework
$result = $db->query("SELECT COUNT(*) as count FROM homework h WHERE h.class_id = {$student['class_id']} AND h.due_date >= CURDATE() AND h.id NOT IN (SELECT homework_id FROM homework_submissions WHERE student_id = $student_id)");
$stats['homework'] = $result->fetch_assoc()['count'];

// Recent Notices
$result = $db->query("SELECT * FROM notices WHERE target_audience IN ('all', 'students') ORDER BY created_at DESC LIMIT 5");
$notices = [];
while ($row = $result->fetch_assoc()) {
    $notices[] = $row;
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> My Attendance</a></li>
                    <li><a href="grades.php"><i class="fas fa-chart-line"></i> My Grades</a></li>
                    <li><a href="homework.php"><i class="fas fa-book-reader"></i> Homework</a></li>
                    <li><a href="notices.php"><i class="fas fa-bullhorn"></i> Notices</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Welcome, <?php echo htmlspecialchars($student['full_name']); ?></h2>

            <!-- Statistics Cards -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo $stats['attendance_percent']; ?>%</div>
                                <div class="stat-label">Attendance This Month</div>
                            </div>
                            <div class="stat-icon primary">
                                <i class="fas fa-calendar-check"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo $stats['homework']; ?></div>
                                <div class="stat-label">Pending Homework</div>
                            </div>
                            <div class="stat-icon warning">
                                <i class="fas fa-book-reader"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo htmlspecialchars($student['class_name'] . ' ' . ($student['section'] ?? '')); ?></div>
                                <div class="stat-label">Current Class</div>
                            </div>
                            <div class="stat-icon success">
                                <i class="fas fa-school"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Notices -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-bullhorn"></i> Recent Notices</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($notices)): ?>
                        <p class="text-muted">No notices available.</p>
                    <?php else: ?>
                        <div class="list-group">
                            <?php foreach ($notices as $notice): ?>
                                <div class="list-group-item">
                                    <h6><?php echo htmlspecialchars($notice['title']); ?></h6>
                                    <p class="mb-1"><?php echo nl2br(htmlspecialchars($notice['content'])); ?></p>
                                    <small class="text-muted"><?php echo formatDateTime($notice['created_at']); ?></small>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

