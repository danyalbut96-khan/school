# School Management System

A complete, professional School Management System built with PHP, MySQL, HTML, CSS, and JavaScript. This system is designed for schools to efficiently manage students, teachers, parents, and classes.

## Features

### User Roles

1. **Admin**
   - Full control over the system
   - Add/Edit/Delete students, teachers, classes, subjects
   - Manage examinations and results
   - Handle fees and payments
   - Create and manage notices/announcements
   - View comprehensive reports

2. **Teacher**
   - Take attendance for classes
   - Upload marks and grades
   - Assign and grade homework
   - View class schedules
   - Manage profile

3. **Student**
   - View attendance records
   - Check grades and marks
   - View and submit homework
   - Read announcements
   - Manage profile

4. **Parent**
   - View child's attendance
   - Check child's grades and progress
   - View fee records and payments
   - Read announcements
   - Manage profile

### Key Features

- ✅ Secure login & registration with session-based authentication
- ✅ Role-based dashboards for each user type
- ✅ Attendance management (daily and monthly reports)
- ✅ Class and subject management
- ✅ Marks & examination management
- ✅ Homework/assignment upload and download system
- ✅ Fees management system (record payments, dues, and receipts)
- ✅ Noticeboard and announcements section
- ✅ Profile management (edit details, change password)
- ✅ Responsive UI with modern design
- ✅ Search functionality
- ✅ Input validation and security measures

## Technology Stack

- **Backend**: PHP 7.4+ (with MySQLi)
- **Database**: MySQL 5.7+
- **Frontend**: HTML5, CSS3, JavaScript
- **Framework**: Bootstrap 5.3
- **Icons**: Font Awesome 6.4

## Installation & Setup

### Prerequisites

- PHP 7.4 or higher
- MySQL 5.7 or higher
- Apache/Nginx web server
- phpMyAdmin (optional, for database management)

### Step 1: Download/Clone the Project

Download the project files and extract them to your web server directory:
- **XAMPP**: `C:\xampp\htdocs\school-management`
- **WAMP**: `C:\wamp\www\school-management`
- **cPanel**: Upload to `public_html/school-management` or your domain folder

### Step 2: Database Setup

1. Open phpMyAdmin (or your MySQL client)
2. Create a new database named `school_db`
3. Import the `school_db.sql` file:
   - Click on the `school_db` database
   - Go to the "Import" tab
   - Choose file: `school_db.sql`
   - Click "Go"

Alternatively, you can run the SQL file via command line:
```bash
mysql -u root -p school_db < school_db.sql
```

### Step 3: Configure Database Connection

Edit the file `config/database.php` and update the database credentials:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // Your MySQL username
define('DB_PASS', '');            // Your MySQL password
define('DB_NAME', 'school_db');
```

For cPanel/hosting:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_cpanel_db_user');
define('DB_PASS', 'your_cpanel_db_password');
define('DB_NAME', 'your_cpanel_db_name');
```

### Step 4: Set Up File Permissions

Create an `uploads` folder in the root directory and set proper permissions:
```bash
mkdir uploads
chmod 755 uploads
```

### Step 5: Access the Application

1. Start your web server (Apache) and MySQL
2. Open your browser and navigate to:
   - **Local**: `http://localhost/school-management`
   - **cPanel**: `http://yourdomain.com/school-management`

### Step 6: Default Login Credentials

**Admin Login:**
- Username: `admin`
- Password: `admin123`

**Note**: Please change the default admin password after first login!

## Project Structure

```
school-management/
├── admin/              # Admin panel files
│   ├── dashboard.php
│   ├── students.php
│   ├── teachers.php
│   ├── classes.php
│   ├── notices.php
│   └── profile.php
├── teacher/            # Teacher panel files
│   ├── dashboard.php
│   ├── attendance.php
│   ├── marks.php
│   ├── homework.php
│   └── profile.php
├── student/            # Student panel files
│   ├── dashboard.php
│   ├── attendance.php
│   ├── grades.php
│   ├── homework.php
│   └── profile.php
├── parent/             # Parent panel files
│   ├── dashboard.php
│   ├── attendance.php
│   ├── grades.php
│   ├── fees.php
│   └── profile.php
├── config/             # Configuration files
│   ├── database.php
│   └── functions.php
├── includes/           # Shared includes
│   ├── header.php
│   └── footer.php
├── assets/             # Static assets
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── main.js
├── uploads/            # File uploads directory
├── index.php           # Home page
├── login.php           # Login page
├── logout.php          # Logout handler
├── unauthorized.php   # Unauthorized access page
└── school_db.sql      # Database schema
```

## Security Features

- Password hashing using PHP `password_hash()` function
- Session-based authentication
- Input sanitization and validation
- SQL injection prevention using prepared statements
- XSS protection with `htmlspecialchars()`
- Role-based access control

## Customization

### Changing Colors

Edit `assets/css/style.css` and modify the CSS variables:
```css
:root {
    --primary-color: #2563eb;    /* Change primary color */
    --secondary-color: #64748b;
    --success-color: #10b981;
    --danger-color: #ef4444;
}
```

### Adding New Features

The codebase is well-structured and commented. You can easily:
- Add new pages in respective role folders
- Extend database schema in `school_db.sql`
- Add new functions in `config/functions.php`

## Troubleshooting

### Database Connection Error
- Check database credentials in `config/database.php`
- Ensure MySQL service is running
- Verify database name exists

### Session Issues
- Ensure `session_start()` is called before any output
- Check PHP session configuration
- Clear browser cookies

### File Upload Issues
- Check `uploads/` folder permissions (755 or 777)
- Verify `MAX_FILE_SIZE` in `config/database.php`
- Check PHP `upload_max_filesize` in php.ini

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Opera (latest)

## License

This project is open-source and available for educational and commercial use.

## Support

For issues, questions, or contributions, please contact the development team.

## Credits

- Bootstrap 5.3 - UI Framework
- Font Awesome 6.4 - Icons
- PHP - Server-side scripting
- MySQL - Database management

---

**Version**: 1.0.0  
**Last Updated**: 2024  
**Author**: School Management System Development Team

