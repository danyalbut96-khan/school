<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['teacher']);

$pageTitle = "Class Schedule";
$teacherActivePage = 'schedule';
require_once '../includes/header.php';

$userId = $_SESSION['user_id'];
$teacher = $db->query("SELECT * FROM teachers WHERE user_id = $userId")->fetch_assoc();
$teacherDbId = $teacher['id'] ?? 0;

if (!$teacherDbId) {
    setFlashMessage('danger', 'Unable to load teacher profile.');
    redirect('dashboard.php');
}

$daysOfWeek = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

// Fetch classes and subjects for this teacher
$classes = [];
$classResult = $db->query("SELECT DISTINCT c.id, c.class_name, c.section FROM classes c JOIN subjects s ON c.id = s.class_id WHERE s.teacher_id = $teacherDbId ORDER BY c.class_name");
while ($row = $classResult->fetch_assoc()) {
    $classes[] = $row;
}

$subjects = [];
$subjectResult = $db->query("SELECT sub.id, sub.subject_name, sub.class_id, c.class_name, c.section FROM subjects sub JOIN classes c ON sub.class_id = c.id WHERE sub.teacher_id = $teacherDbId ORDER BY c.class_name, sub.subject_name");
while ($row = $subjectResult->fetch_assoc()) {
    $subjects[] = $row;
}

// Handle delete
if (isset($_GET['delete'])) {
    $deleteId = (int)$_GET['delete'];
    $db->query("DELETE FROM class_schedule WHERE id = $deleteId AND teacher_id = $teacherDbId");
    if ($db->getConnection()->affected_rows > 0) {
        setFlashMessage('success', 'Schedule entry removed.');
    } else {
        setFlashMessage('danger', 'Unable to remove the selected schedule entry.');
    }
    redirect('schedule.php');
}

// Handle create
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subjectId = (int)($_POST['subject_id'] ?? 0);
    $dayOfWeek = strtolower(trim($_POST['day_of_week'] ?? ''));
    $startTime = $_POST['start_time'] ?? '';
    $endTime = $_POST['end_time'] ?? '';
    $roomNumberRaw = sanitize($_POST['room_number'] ?? '');

    if (!$subjectId || !in_array($dayOfWeek, $daysOfWeek, true) || empty($startTime) || empty($endTime)) {
        setFlashMessage('danger', 'Please fill in all required fields.');
        redirect('schedule.php');
    }

    if ($startTime >= $endTime) {
        setFlashMessage('danger', 'End time must be later than start time.');
        redirect('schedule.php');
    }

    $subjectInfo = $db->query("SELECT class_id FROM subjects WHERE id = $subjectId AND teacher_id = $teacherDbId LIMIT 1")->fetch_assoc();
    if (!$subjectInfo) {
        setFlashMessage('danger', 'Invalid subject selected.');
        redirect('schedule.php');
    }

    $classId = (int)$subjectInfo['class_id'];
    $roomNumber = $db->escape($roomNumberRaw);
    $roomValue = $roomNumberRaw ? "'$roomNumber'" : 'NULL';

    $db->query("INSERT INTO class_schedule (class_id, subject_id, teacher_id, day_of_week, start_time, end_time, room_number) VALUES ($classId, $subjectId, $teacherDbId, '$dayOfWeek', '$startTime', '$endTime', $roomValue)");
    setFlashMessage('success', 'Schedule entry added successfully.');
    redirect('schedule.php');
}

// Fetch schedule entries
$scheduleEntries = [];
$scheduleResult = $db->query("SELECT cs.*, c.class_name, c.section, s.subject_name FROM class_schedule cs JOIN classes c ON cs.class_id = c.id JOIN subjects s ON cs.subject_id = s.id WHERE cs.teacher_id = $teacherDbId ORDER BY FIELD(cs.day_of_week, 'monday','tuesday','wednesday','thursday','friday','saturday','sunday'), cs.start_time");
while ($row = $scheduleResult->fetch_assoc()) {
    $scheduleEntries[] = $row;
}

?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <?php require '../includes/teacher_sidebar.php'; ?>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Class Schedule</h2>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Add Schedule Entry</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Subject *</label>
                                <select class="form-select" name="subject_id" required>
                                    <option value="">Select Subject</option>
                                    <?php foreach ($subjects as $subject): ?>
                                        <option value="<?php echo $subject['id']; ?>">
                                            <?php echo htmlspecialchars($subject['class_name'] . ' ' . ($subject['section'] ?? '') . ' - ' . $subject['subject_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Day *</label>
                                <select class="form-select" name="day_of_week" required>
                                    <option value="">Select Day</option>
                                    <?php foreach ($daysOfWeek as $day): ?>
                                        <option value="<?php echo $day; ?>"><?php echo ucfirst($day); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2 mb-3">
                                <label class="form-label">Start Time *</label>
                                <input type="time" class="form-control" name="start_time" required>
                            </div>
                            <div class="col-md-2 mb-3">
                                <label class="form-label">End Time *</label>
                                <input type="time" class="form-control" name="end_time" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Room</label>
                                <input type="text" class="form-control" name="room_number" placeholder="e.g. Room 204">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Add Entry
                        </button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">My Schedule</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Day</th>
                                    <th>Class</th>
                                    <th>Subject</th>
                                    <th>Time</th>
                                    <th>Room</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($scheduleEntries)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">No schedule entries found.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($scheduleEntries as $entry): ?>
                                        <tr>
                                            <td><?php echo ucfirst($entry['day_of_week']); ?></td>
                                            <td><?php echo htmlspecialchars($entry['class_name'] . ' ' . ($entry['section'] ?? '')); ?></td>
                                            <td><?php echo htmlspecialchars($entry['subject_name']); ?></td>
                                            <td><?php echo date('h:i A', strtotime($entry['start_time'])) . ' - ' . date('h:i A', strtotime($entry['end_time'])); ?></td>
                                            <td><?php echo htmlspecialchars($entry['room_number'] ?? 'N/A'); ?></td>
                                            <td>
                                                <a href="schedule.php?delete=<?php echo $entry['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmDelete();">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>


