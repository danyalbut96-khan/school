<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['teacher']);

$pageTitle = "Take Attendance";
require_once '../includes/header.php';

$teacher_id = $_SESSION['user_id'];
$teacher_info = $db->query("SELECT t.* FROM teachers t WHERE t.user_id = $teacher_id")->fetch_assoc();
$teacher_db_id = $teacher_info['id'] ?? 0;

// Get teacher's classes
$classes_result = $db->query("SELECT DISTINCT c.* FROM classes c JOIN subjects s ON c.id = s.class_id WHERE s.teacher_id = $teacher_db_id");
$classes = [];
while ($row = $classes_result->fetch_assoc()) {
    $classes[] = $row;
}

$selected_class = $_GET['class_id'] ?? ($classes[0]['id'] ?? 0);
$selected_date = $_GET['date'] ?? date('Y-m-d');
$selected_subject = $_GET['subject_id'] ?? 0;

// Get subjects for selected class
$subjects_result = $db->query("SELECT * FROM subjects WHERE class_id = $selected_class AND teacher_id = $teacher_db_id");
$subjects = [];
while ($row = $subjects_result->fetch_assoc()) {
    $subjects[] = $row;
}

// Handle attendance submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $class_id = (int)$_POST['class_id'];
    $subject_id = !empty($_POST['subject_id']) ? (int)$_POST['subject_id'] : 'NULL';
    $date = $_POST['date'];
    
    foreach ($_POST['attendance'] as $student_id => $status) {
        $student_id = (int)$student_id;
        $status = sanitize($status);
        
        // Delete existing attendance for this date/subject
        $db->query("DELETE FROM attendance WHERE student_id = $student_id AND date = '$date' AND subject_id = $subject_id");
        
        // Insert new attendance
        $db->query("INSERT INTO attendance (student_id, class_id, subject_id, date, status, marked_by) VALUES ($student_id, $class_id, $subject_id, '$date', '$status', $teacher_db_id)");
    }
    
    setFlashMessage('success', 'Attendance marked successfully');
    redirect("attendance.php?class_id=$class_id&date=$date&subject_id=$selected_subject");
}

// Get students for selected class
$students = [];
if ($selected_class) {
    $students_result = $db->query("SELECT * FROM students WHERE class_id = $selected_class ORDER BY full_name");
    while ($row = $students_result->fetch_assoc()) {
        // Get today's attendance if exists
        $attendance_result = $db->query("SELECT status FROM attendance WHERE student_id = {$row['id']} AND date = '$selected_date' AND subject_id = " . ($selected_subject ?: 'NULL'));
        $row['attendance_status'] = $attendance_result->num_rows > 0 ? $attendance_result->fetch_assoc()['status'] : 'absent';
        $students[] = $row;
    }
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="attendance.php" class="active"><i class="fas fa-calendar-check"></i> Take Attendance</a></li>
                    <li><a href="marks.php"><i class="fas fa-clipboard-list"></i> Upload Marks</a></li>
                    <li><a href="homework.php"><i class="fas fa-book-reader"></i> Homework</a></li>
                    <li><a href="schedule.php"><i class="fas fa-calendar-alt"></i> Schedule</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Take Attendance</h2>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Select Class and Date</h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Class</label>
                                <select class="form-select" name="class_id" onchange="this.form.submit()">
                                    <?php foreach ($classes as $class): ?>
                                        <option value="<?php echo $class['id']; ?>" <?php echo $selected_class == $class['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($class['class_name'] . ' ' . ($class['section'] ?? '')); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Subject (Optional)</label>
                                <select class="form-select" name="subject_id" onchange="this.form.submit()">
                                    <option value="">All Subjects</option>
                                    <?php foreach ($subjects as $subject): ?>
                                        <option value="<?php echo $subject['id']; ?>" <?php echo $selected_subject == $subject['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($subject['subject_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Date</label>
                                <input type="date" class="form-control" name="date" value="<?php echo $selected_date; ?>" onchange="this.form.submit()">
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <?php if (!empty($students)): ?>
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Mark Attendance</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <input type="hidden" name="class_id" value="<?php echo $selected_class; ?>">
                        <input type="hidden" name="subject_id" value="<?php echo $selected_subject; ?>">
                        <input type="hidden" name="date" value="<?php echo $selected_date; ?>">
                        
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Student ID</th>
                                        <th>Name</th>
                                        <th>Present</th>
                                        <th>Absent</th>
                                        <th>Late</th>
                                        <th>Excused</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($students as $student): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                                            <td><?php echo htmlspecialchars($student['full_name']); ?></td>
                                            <td>
                                                <input type="radio" name="attendance[<?php echo $student['id']; ?>]" value="present" <?php echo $student['attendance_status'] == 'present' ? 'checked' : ''; ?> required>
                                            </td>
                                            <td>
                                                <input type="radio" name="attendance[<?php echo $student['id']; ?>]" value="absent" <?php echo $student['attendance_status'] == 'absent' ? 'checked' : ''; ?>>
                                            </td>
                                            <td>
                                                <input type="radio" name="attendance[<?php echo $student['id']; ?>]" value="late" <?php echo $student['attendance_status'] == 'late' ? 'checked' : ''; ?>>
                                            </td>
                                            <td>
                                                <input type="radio" name="attendance[<?php echo $student['id']; ?>]" value="excused" <?php echo $student['attendance_status'] == 'excused' ? 'checked' : ''; ?>>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Attendance
                        </button>
                    </form>
                </div>
            </div>
            <?php else: ?>
                <div class="alert alert-info">Please select a class to view students.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

