<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['teacher']);

$pageTitle = "Manage Examinations";
$teacherActivePage = 'examinations';
require_once '../includes/header.php';

$userId = $_SESSION['user_id'];
$teacher = $db->query("SELECT * FROM teachers WHERE user_id = $userId")->fetch_assoc();
$teacherDbId = $teacher['id'] ?? 0;

if (!$teacherDbId) {
    setFlashMessage('danger', 'Unable to load your teacher profile.');
    redirect('dashboard.php');
}

// Fetch classes and subjects for this teacher
$classes = [];
$classResult = $db->query("SELECT DISTINCT c.id, c.class_name, c.section FROM classes c JOIN subjects s ON c.id = s.class_id WHERE s.teacher_id = $teacherDbId ORDER BY c.class_name");
while ($row = $classResult->fetch_assoc()) {
    $classes[] = $row;
}

$subjects = [];
$subjectResult = $db->query("SELECT sub.id, sub.subject_name, sub.class_id, c.class_name, c.section FROM subjects sub JOIN classes c ON sub.class_id = c.id WHERE sub.teacher_id = $teacherDbId ORDER BY c.class_name, sub.subject_name");
while ($row = $subjectResult->fetch_assoc()) {
    $subjects[] = $row;
}

// Determine if editing an exam
$editingExam = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $examResult = $db->query("SELECT * FROM examinations WHERE id = $editId AND created_by = $teacherDbId LIMIT 1");
    if ($examResult && $examResult->num_rows === 1) {
        $editingExam = $examResult->fetch_assoc();
    } else {
        setFlashMessage('danger', 'Examination not found or access denied.');
        redirect('examinations.php');
    }
}

// Handle deletion
if (isset($_GET['delete'])) {
    $deleteId = (int)$_GET['delete'];
    $db->query("DELETE FROM examinations WHERE id = $deleteId AND created_by = $teacherDbId");
    if ($db->getConnection()->affected_rows > 0) {
        setFlashMessage('success', 'Examination removed successfully.');
    } else {
        setFlashMessage('danger', 'Unable to delete the examination.');
    }
    redirect('examinations.php');
}

$examTypes = ['quiz' => 'Quiz', 'midterm' => 'Midterm', 'final' => 'Final', 'assignment' => 'Assignment'];

// Handle create/update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $examId = isset($_POST['exam_id']) ? (int)$_POST['exam_id'] : 0;
    $examNameRaw = sanitize($_POST['exam_name'] ?? '');
    $examType = $_POST['exam_type'] ?? '';
    $subjectId = (int)($_POST['subject_id'] ?? 0);
    $examDate = $_POST['exam_date'] ?? null;
    $totalMarks = (float)($_POST['total_marks'] ?? 100);
    $passingMarks = (float)($_POST['passing_marks'] ?? 40);

    if (empty($examNameRaw) || empty($examType) || !$subjectId) {
        setFlashMessage('danger', 'Please complete all required fields.');
        redirect('examinations.php' . ($examId ? '?edit=' . $examId : ''));
    }

    if (!array_key_exists($examType, $examTypes)) {
        setFlashMessage('danger', 'Invalid examination type selected.');
        redirect('examinations.php');
    }

    $examName = $db->escape($examNameRaw);
    $subjectInfo = $db->query("SELECT class_id FROM subjects WHERE id = $subjectId AND teacher_id = $teacherDbId LIMIT 1")->fetch_assoc();
    if (!$subjectInfo) {
        setFlashMessage('danger', 'Invalid subject selection.');
        redirect('examinations.php');
    }

    $classId = (int)$subjectInfo['class_id'];
    $examDateValue = $examDate ? "'$examDate'" : 'NULL';

    if ($examId > 0) {
        $exists = $db->query("SELECT id FROM examinations WHERE id = $examId AND created_by = $teacherDbId");
        if ($exists && $exists->num_rows === 1) {
            $db->query("UPDATE examinations SET exam_name = '$examName', exam_type = '$examType', class_id = $classId, subject_id = $subjectId, exam_date = $examDateValue, total_marks = $totalMarks, passing_marks = $passingMarks WHERE id = $examId");
            setFlashMessage('success', 'Examination updated successfully.');
        } else {
            setFlashMessage('danger', 'Unable to update the examination.');
        }
    } else {
        $db->query("INSERT INTO examinations (exam_name, exam_type, class_id, subject_id, exam_date, total_marks, passing_marks, created_by) VALUES ('$examName', '$examType', $classId, $subjectId, $examDateValue, $totalMarks, $passingMarks, $teacherDbId)");
        setFlashMessage('success', 'Examination created successfully.');
    }

    redirect('examinations.php');
}

// Fetch teacher examinations
$examinations = [];
$examList = $db->query("SELECT e.*, c.class_name, c.section, s.subject_name FROM examinations e JOIN classes c ON e.class_id = c.id JOIN subjects s ON e.subject_id = s.id WHERE e.created_by = $teacherDbId ORDER BY e.exam_date DESC, e.created_at DESC");
while ($row = $examList->fetch_assoc()) {
    $examinations[] = $row;
}

// already defined above
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <?php require '../includes/teacher_sidebar.php'; ?>
        </div>

        <div class="col-md-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><?php echo $editingExam ? 'Edit Examination' : 'Manage Examinations'; ?></h2>
                <?php if ($editingExam): ?>
                    <a href="examinations.php" class="btn btn-secondary"><i class="fas fa-undo"></i> Cancel Edit</a>
                <?php endif; ?>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><?php echo $editingExam ? 'Update Examination' : 'Create Examination'; ?></h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <?php if ($editingExam): ?>
                            <input type="hidden" name="exam_id" value="<?php echo $editingExam['id']; ?>">
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Exam Title *</label>
                                <input type="text" class="form-control" name="exam_name" value="<?php echo htmlspecialchars($editingExam['exam_name'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label class="form-label">Exam Type *</label>
                                <select class="form-select" name="exam_type" required>
                                    <option value="">Select Type</option>
                                    <?php foreach ($examTypes as $value => $label): ?>
                                        <option value="<?php echo $value; ?>" <?php echo ($editingExam['exam_type'] ?? '') === $value ? 'selected' : ''; ?>>
                                            <?php echo $label; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label class="form-label">Exam Date</label>
                                <input type="date" class="form-control" name="exam_date" value="<?php echo $editingExam && $editingExam['exam_date'] ? $editingExam['exam_date'] : ''; ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Subject *</label>
                                <select class="form-select" name="subject_id" required>
                                    <option value="">Select Subject</option>
                                    <?php foreach ($subjects as $subject): ?>
                                        <option value="<?php echo $subject['id']; ?>" <?php echo ($editingExam['subject_id'] ?? 0) == $subject['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($subject['class_name'] . ' ' . ($subject['section'] ?? '') . ' - ' . $subject['subject_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label class="form-label">Total Marks</label>
                                <input type="number" step="0.1" class="form-control" name="total_marks" value="<?php echo htmlspecialchars($editingExam['total_marks'] ?? 100); ?>">
                            </div>
                            <div class="col-md-3 mb-3">
                                <label class="form-label">Passing Marks</label>
                                <input type="number" step="0.1" class="form-control" name="passing_marks" value="<?php echo htmlspecialchars($editingExam['passing_marks'] ?? 40); ?>">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> <?php echo $editingExam ? 'Update Examination' : 'Create Examination'; ?>
                        </button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Scheduled Examinations</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Exam</th>
                                    <th>Type</th>
                                    <th>Class</th>
                                    <th>Subject</th>
                                    <th>Date</th>
                                    <th>Total</th>
                                    <th>Passing</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($examinations)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center">No examinations scheduled yet.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($examinations as $exam): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($exam['exam_name']); ?></td>
                                            <td><span class="badge bg-info text-dark"><?php echo ucfirst($exam['exam_type']); ?></span></td>
                                            <td><?php echo htmlspecialchars($exam['class_name'] . ' ' . ($exam['section'] ?? '')); ?></td>
                                            <td><?php echo htmlspecialchars($exam['subject_name']); ?></td>
                                            <td><?php echo $exam['exam_date'] ? formatDate($exam['exam_date']) : 'TBD'; ?></td>
                                            <td><?php echo $exam['total_marks']; ?></td>
                                            <td><?php echo $exam['passing_marks']; ?></td>
                                            <td>
                                                <a href="examinations.php?edit=<?php echo $exam['id']; ?>" class="btn btn-sm btn-warning">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <a href="examinations.php?delete=<?php echo $exam['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmDelete();">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>


