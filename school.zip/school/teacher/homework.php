<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['teacher']);

$pageTitle = "Assign Homework";
$teacherActivePage = 'homework';
require_once '../includes/header.php';

$userId = $_SESSION['user_id'];
$teacher = $db->query("SELECT * FROM teachers WHERE user_id = $userId")->fetch_assoc();
$teacherDbId = $teacher['id'] ?? 0;

if (!$teacherDbId) {
    setFlashMessage('danger', 'Unable to load teacher profile.');
    redirect('dashboard.php');
}

// Fetch classes and subjects
$classes = [];
$classResult = $db->query("SELECT DISTINCT c.id, c.class_name, c.section FROM classes c JOIN subjects s ON c.id = s.class_id WHERE s.teacher_id = $teacherDbId ORDER BY c.class_name");
while ($row = $classResult->fetch_assoc()) {
    $classes[] = $row;
}

$subjects = [];
$subjectResult = $db->query("SELECT sub.id, sub.subject_name, sub.class_id, c.class_name, c.section FROM subjects sub JOIN classes c ON sub.class_id = c.id WHERE sub.teacher_id = $teacherDbId ORDER BY c.class_name, sub.subject_name");
while ($row = $subjectResult->fetch_assoc()) {
    $subjects[] = $row;
}

// Handle delete
if (isset($_GET['delete'])) {
    $deleteId = (int)$_GET['delete'];
    $db->query("DELETE FROM homework WHERE id = $deleteId AND teacher_id = $teacherDbId");
    if ($db->getConnection()->affected_rows > 0) {
        setFlashMessage('success', 'Homework deleted successfully.');
    } else {
        setFlashMessage('danger', 'Unable to delete selected homework.');
    }
    redirect('homework.php');
}

// Handle create
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titleRaw = sanitize($_POST['title'] ?? '');
    $descriptionRaw = sanitize($_POST['description'] ?? '');
    $subjectId = (int)($_POST['subject_id'] ?? 0);
    $dueDate = $_POST['due_date'] ?? null;

    if (empty($titleRaw) || !$subjectId) {
        setFlashMessage('danger', 'Please provide a title and select a subject.');
        redirect('homework.php');
    }

    $subjectInfo = $db->query("SELECT class_id FROM subjects WHERE id = $subjectId AND teacher_id = $teacherDbId LIMIT 1")->fetch_assoc();
    if (!$subjectInfo) {
        setFlashMessage('danger', 'Invalid subject selected.');
        redirect('homework.php');
    }

    $classId = (int)$subjectInfo['class_id'];
    $title = $db->escape($titleRaw);
    $descriptionEscaped = $db->escape($descriptionRaw);
    $dueDateValue = $dueDate ? "'$dueDate'" : 'NULL';
    $descriptionValue = $descriptionRaw ? "'$descriptionEscaped'" : 'NULL';

    $db->query("INSERT INTO homework (title, description, class_id, subject_id, teacher_id, due_date) VALUES ('$title', $descriptionValue, $classId, $subjectId, $teacherDbId, $dueDateValue)");
    setFlashMessage('success', 'Homework assigned successfully.');
    redirect('homework.php');
}

// Fetch homework list
$homeworkList = [];
$homeworkResult = $db->query("SELECT h.*, c.class_name, c.section, s.subject_name FROM homework h JOIN classes c ON h.class_id = c.id JOIN subjects s ON h.subject_id = s.id WHERE h.teacher_id = $teacherDbId ORDER BY h.due_date DESC, h.created_at DESC");
while ($row = $homeworkResult->fetch_assoc()) {
    $homeworkList[] = $row;
}

?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <?php require '../includes/teacher_sidebar.php'; ?>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Assign Homework</h2>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Create Homework</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Title *</label>
                                <input type="text" class="form-control" name="title" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Subject *</label>
                                <select class="form-select" name="subject_id" required>
                                    <option value="">Select Subject</option>
                                    <?php foreach ($subjects as $subject): ?>
                                        <option value="<?php echo $subject['id']; ?>">
                                            <?php echo htmlspecialchars($subject['class_name'] . ' ' . ($subject['section'] ?? '') . ' - ' . $subject['subject_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Due Date</label>
                                <input type="date" class="form-control" name="due_date">
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Description</label>
                                <textarea class="form-control" name="description" rows="3" placeholder="Provide instructions or details"></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane"></i> Assign Homework
                        </button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Assigned Homework</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Class</th>
                                    <th>Subject</th>
                                    <th>Due Date</th>
                                    <th>Assigned On</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($homeworkList)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">No homework assigned yet.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($homeworkList as $homework): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($homework['title']); ?></td>
                                            <td><?php echo htmlspecialchars($homework['class_name'] . ' ' . ($homework['section'] ?? '')); ?></td>
                                            <td><?php echo htmlspecialchars($homework['subject_name']); ?></td>
                                            <td><?php echo $homework['due_date'] ? formatDate($homework['due_date']) : 'Not set'; ?></td>
                                            <td><?php echo formatDateTime($homework['created_at']); ?></td>
                                            <td>
                                                <a href="homework.php?delete=<?php echo $homework['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmDelete();">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>


