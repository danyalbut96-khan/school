<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['teacher']);

$pageTitle = "Teacher Dashboard";
require_once '../includes/header.php';

$teacher_id = $_SESSION['user_id'];
$teacher_info = $db->query("SELECT t.* FROM teachers t WHERE t.user_id = $teacher_id")->fetch_assoc();
$teacher_db_id = $teacher_info['id'] ?? 0;

// Get statistics
$stats = [];

// My Classes
$result = $db->query("SELECT COUNT(DISTINCT class_id) as count FROM subjects WHERE teacher_id = $teacher_db_id");
$stats['classes'] = $result->fetch_assoc()['count'];

// My Subjects
$result = $db->query("SELECT COUNT(*) as count FROM subjects WHERE teacher_id = $teacher_db_id");
$stats['subjects'] = $result->fetch_assoc()['count'];

// Students in my classes
$result = $db->query("SELECT COUNT(DISTINCT s.id) as count FROM students s JOIN subjects sub ON s.class_id = sub.class_id WHERE sub.teacher_id = $teacher_db_id");
$stats['students'] = $result->fetch_assoc()['count'];

// Pending homework submissions
$result = $db->query("SELECT COUNT(*) as count FROM homework_submissions hs JOIN homework h ON hs.homework_id = h.id WHERE h.teacher_id = $teacher_db_id AND hs.status = 'submitted'");
$stats['homework'] = $result->fetch_assoc()['count'];
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> Take Attendance</a></li>
                    <li><a href="marks.php"><i class="fas fa-clipboard-list"></i> Upload Marks</a></li>
                    <li><a href="homework.php"><i class="fas fa-book-reader"></i> Homework</a></li>
                    <li><a href="schedule.php"><i class="fas fa-calendar-alt"></i> Schedule</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Welcome, <?php echo htmlspecialchars($teacher_info['full_name'] ?? 'Teacher'); ?></h2>

            <!-- Statistics Cards -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo $stats['classes']; ?></div>
                                <div class="stat-label">My Classes</div>
                            </div>
                            <div class="stat-icon primary">
                                <i class="fas fa-school"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo $stats['subjects']; ?></div>
                                <div class="stat-label">Subjects</div>
                            </div>
                            <div class="stat-icon success">
                                <i class="fas fa-book"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo $stats['students']; ?></div>
                                <div class="stat-label">Students</div>
                            </div>
                            <div class="stat-icon warning">
                                <i class="fas fa-user-graduate"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo $stats['homework']; ?></div>
                                <div class="stat-label">Pending Homework</div>
                            </div>
                            <div class="stat-icon danger">
                                <i class="fas fa-book-reader"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="row">
                <div class="col-md-6 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-calendar-check fa-3x text-primary mb-3"></i>
                            <h5>Take Attendance</h5>
                            <p class="text-muted">Mark attendance for your classes</p>
                            <a href="attendance.php" class="btn btn-primary">Go to Attendance</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-clipboard-list fa-3x text-success mb-3"></i>
                            <h5>Upload Marks</h5>
                            <p class="text-muted">Enter examination marks</p>
                            <a href="marks.php" class="btn btn-success">Go to Marks</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

