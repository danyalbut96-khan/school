<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['teacher']);

$pageTitle = "Upload Marks";
require_once '../includes/header.php';

$teacher_id = $_SESSION['user_id'];
$teacher_info = $db->query("SELECT t.* FROM teachers t WHERE t.user_id = $teacher_id")->fetch_assoc();
$teacher_db_id = $teacher_info['id'] ?? 0;

// Get teacher's examinations
$exams_result = $db->query("SELECT e.*, c.class_name, s.subject_name FROM examinations e JOIN classes c ON e.class_id = c.id JOIN subjects s ON e.subject_id = s.id WHERE e.created_by = $teacher_db_id ORDER BY e.created_at DESC");
$exams = [];
while ($row = $exams_result->fetch_assoc()) {
    $exams[] = $row;
}

$selected_exam = $_GET['exam_id'] ?? 0;

// Handle marks submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $exam_id = (int)$_POST['exam_id'];
    $subject_id = (int)$_POST['subject_id'];
    
    foreach ($_POST['marks'] as $student_id => $marks_data) {
        $student_id = (int)$student_id;
        $marks_obtained = (float)$marks_data['marks'];
        $grade = sanitize($marks_data['grade'] ?? '');
        
        // Calculate grade if not provided
        if (empty($grade)) {
            if ($marks_obtained >= 90) $grade = 'A+';
            elseif ($marks_obtained >= 80) $grade = 'A';
            elseif ($marks_obtained >= 70) $grade = 'B';
            elseif ($marks_obtained >= 60) $grade = 'C';
            elseif ($marks_obtained >= 50) $grade = 'D';
            else $grade = 'F';
        }
        
        // Delete existing marks
        $db->query("DELETE FROM marks WHERE student_id = $student_id AND examination_id = $exam_id AND subject_id = $subject_id");
        
        // Insert new marks
        $db->query("INSERT INTO marks (student_id, examination_id, subject_id, marks_obtained, grade) VALUES ($student_id, $exam_id, $subject_id, $marks_obtained, '$grade')");
    }
    
    setFlashMessage('success', 'Marks uploaded successfully');
    redirect("marks.php?exam_id=$exam_id");
}

// Get students and marks for selected exam
$students = [];
$exam_info = null;
if ($selected_exam) {
    $exam_info = $db->query("SELECT e.*, c.class_name, s.subject_name FROM examinations e JOIN classes c ON e.class_id = c.id JOIN subjects s ON e.subject_id = s.id WHERE e.id = $selected_exam")->fetch_assoc();
    
    if ($exam_info) {
        $students_result = $db->query("SELECT s.*, m.marks_obtained, m.grade FROM students s LEFT JOIN marks m ON s.id = m.student_id AND m.examination_id = $selected_exam AND m.subject_id = {$exam_info['subject_id']} WHERE s.class_id = {$exam_info['class_id']} ORDER BY s.full_name");
        while ($row = $students_result->fetch_assoc()) {
            $students[] = $row;
        }
    }
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> Take Attendance</a></li>
                    <li><a href="marks.php" class="active"><i class="fas fa-clipboard-list"></i> Upload Marks</a></li>
                    <li><a href="homework.php"><i class="fas fa-book-reader"></i> Homework</a></li>
                    <li><a href="schedule.php"><i class="fas fa-calendar-alt"></i> Schedule</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Upload Marks</h2>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Select Examination</h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="">
                        <select class="form-select" name="exam_id" onchange="this.form.submit()">
                            <option value="">Select Examination</option>
                            <?php foreach ($exams as $exam): ?>
                                <option value="<?php echo $exam['id']; ?>" <?php echo $selected_exam == $exam['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($exam['exam_name'] . ' - ' . $exam['class_name'] . ' - ' . $exam['subject_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                </div>
            </div>

            <?php if ($exam_info && !empty($students)): ?>
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Enter Marks - <?php echo htmlspecialchars($exam_info['exam_name']); ?> (Total: <?php echo $exam_info['total_marks']; ?>)</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <input type="hidden" name="exam_id" value="<?php echo $selected_exam; ?>">
                        <input type="hidden" name="subject_id" value="<?php echo $exam_info['subject_id']; ?>">
                        
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Student ID</th>
                                        <th>Name</th>
                                        <th>Marks Obtained</th>
                                        <th>Grade</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($students as $student): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                                            <td><?php echo htmlspecialchars($student['full_name']); ?></td>
                                            <td>
                                                <input type="number" class="form-control" name="marks[<?php echo $student['id']; ?>][marks]" 
                                                       value="<?php echo $student['marks_obtained'] ?? ''; ?>" 
                                                       min="0" max="<?php echo $exam_info['total_marks']; ?>" step="0.01" required>
                                            </td>
                                            <td>
                                                <input type="text" class="form-control" name="marks[<?php echo $student['id']; ?>][grade]" 
                                                       value="<?php echo htmlspecialchars($student['grade'] ?? ''); ?>" 
                                                       placeholder="A+, A, B, C, D, F">
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Marks
                        </button>
                    </form>
                </div>
            </div>
            <?php elseif ($selected_exam): ?>
                <div class="alert alert-info">No students found for this examination.</div>
            <?php else: ?>
                <div class="alert alert-info">Please select an examination to upload marks.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

