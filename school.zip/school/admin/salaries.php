<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['admin']);

$pageTitle = "Teacher Salaries";
$activePage = 'salaries';
require_once '../includes/header.php';

$selectedMonth = $_GET['month'] ?? date('Y-m');
$monthDate = DateTime::createFromFormat('Y-m', $selectedMonth) ?: new DateTime();
$salaryMonth = $monthDate->format('Y-m-01');

$editingSalary = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $result = $db->query("SELECT * FROM teacher_salaries WHERE id = $editId");
    if ($result && $result->num_rows === 1) {
        $editingSalary = $result->fetch_assoc();
        if ($editingSalary && isset($editingSalary['salary_month'])) {
            $selectedMonth = DateTime::createFromFormat('Y-m-d', $editingSalary['salary_month'])->format('Y-m');
            $salaryMonth = $editingSalary['salary_month'];
        }
    } else {
        setFlashMessage('danger', 'Salary record not found.');
        redirect('salaries.php?month=' . $selectedMonth);
    }
}

if (isset($_GET['delete'])) {
    $deleteId = (int)$_GET['delete'];
    $db->query("DELETE FROM teacher_salaries WHERE id = $deleteId");
    setFlashMessage('success', 'Salary record removed.');
    redirect('salaries.php?month=' . $selectedMonth);
}

if (isset($_GET['mark_paid'])) {
    $markId = (int)$_GET['mark_paid'];
    $entry = $db->query("SELECT amount FROM teacher_salaries WHERE id = $markId")->fetch_assoc();
    if ($entry) {
        $amount = $entry['amount'];
        $db->query("UPDATE teacher_salaries SET status = 'paid', paid_amount = $amount WHERE id = $markId");
        setFlashMessage('success', 'Salary marked as paid.');
    } else {
        setFlashMessage('danger', 'Unable to update salary status.');
    }
    redirect('salaries.php?month=' . $selectedMonth);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $salaryId = isset($_POST['salary_id']) ? (int)$_POST['salary_id'] : 0;
    $teacherId = (int)($_POST['teacher_id'] ?? 0);
    $amount = (float)($_POST['amount'] ?? 0);
    $paidAmount = (float)($_POST['paid_amount'] ?? 0);
    $status = $_POST['status'] ?? 'pending';
    $notesRaw = sanitize($_POST['notes'] ?? '');
    $formMonth = $_POST['salary_month'] ?? $selectedMonth;
    $monthObject = DateTime::createFromFormat('Y-m', $formMonth) ?: new DateTime();
    $salaryMonth = $monthObject->format('Y-m-01');

    if (!$teacherId || $amount <= 0) {
        setFlashMessage('danger', 'Please select a teacher and provide a valid amount.');
        redirect('salaries.php?month=' . $monthObject->format('Y-m'));
    }

    $validStatuses = ['pending', 'partial', 'paid'];
    if (!in_array($status, $validStatuses, true)) {
        $status = 'pending';
    }

    if ($paidAmount < 0) {
        $paidAmount = 0;
    }
    if ($paidAmount >= $amount) {
        $paidAmount = $amount;
        $status = 'paid';
    } elseif ($paidAmount > 0) {
        $status = 'partial';
    }

    $notes = $db->escape($notesRaw);
    $notesValue = $notesRaw ? "'$notes'" : 'NULL';

    if ($salaryId) {
        $db->query("UPDATE teacher_salaries SET teacher_id = $teacherId, salary_month = '$salaryMonth', amount = $amount, paid_amount = $paidAmount, status = '$status', notes = $notesValue WHERE id = $salaryId");
        setFlashMessage('success', 'Salary record updated successfully.');
    } else {
        $existing = $db->query("SELECT id FROM teacher_salaries WHERE teacher_id = $teacherId AND salary_month = '$salaryMonth'");
        if ($existing && $existing->num_rows > 0) {
            $existingId = $existing->fetch_assoc()['id'];
            $db->query("UPDATE teacher_salaries SET amount = $amount, paid_amount = $paidAmount, status = '$status', notes = $notesValue WHERE id = $existingId");
        } else {
            $db->query("INSERT INTO teacher_salaries (teacher_id, salary_month, amount, paid_amount, status, notes) VALUES ($teacherId, '$salaryMonth', $amount, $paidAmount, '$status', $notesValue)");
        }
        setFlashMessage('success', 'Salary record saved successfully.');
    }

    redirect('salaries.php?month=' . $monthObject->format('Y-m'));
}

$teachers = [];
$teacherResult = $db->query("SELECT t.id, t.full_name, t.salary, ts.id AS salary_id, ts.amount, ts.paid_amount, ts.status, ts.notes, ts.updated_at
                              FROM teachers t
                              LEFT JOIN teacher_salaries ts ON ts.teacher_id = t.id AND ts.salary_month = '$salaryMonth'
                              ORDER BY t.full_name");
while ($row = $teacherResult->fetch_assoc()) {
    $teachers[] = $row;
}

$summary = [
    'total_expected' => 0,
    'total_paid' => 0,
    'pending' => 0,
    'partial' => 0,
    'paid' => 0,
];

foreach ($teachers as $teacher) {
    $expected = $teacher['amount'] !== null ? $teacher['amount'] : (float)($teacher['salary'] ?? 0);
    $paid = $teacher['paid_amount'] !== null ? $teacher['paid_amount'] : 0;
    $status = $teacher['status'] ?? 'pending';

    $summary['total_expected'] += $expected;
    $summary['total_paid'] += $paid;
    if (isset($summary[$status])) {
        $summary[$status]++;
    }
}

$summary['remaining'] = max($summary['total_expected'] - $summary['total_paid'], 0);

$statusLabels = [
    'pending' => 'Pending',
    'partial' => 'Partial',
    'paid' => 'Paid',
];
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <?php require '../includes/admin_sidebar.php'; ?>
        </div>

        <div class="col-md-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="mb-0">Teacher Salaries</h2>
                <form method="GET" action="" class="d-flex align-items-center">
                    <label class="me-2 mb-0">Month</label>
                    <input type="month" class="form-control" name="month" value="<?php echo htmlspecialchars($selectedMonth); ?>" onchange="this.form.submit()">
                </form>
            </div>

            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number">$<?php echo number_format($summary['total_expected'], 2); ?></div>
                                <div class="stat-label">Total Salaries</div>
                            </div>
                            <div class="stat-icon primary">
                                <i class="fas fa-wallet"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number">$<?php echo number_format($summary['total_paid'], 2); ?></div>
                                <div class="stat-label">Paid</div>
                            </div>
                            <div class="stat-icon success">
                                <i class="fas fa-check-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number">$<?php echo number_format($summary['remaining'], 2); ?></div>
                                <div class="stat-label">Outstanding</div>
                            </div>
                            <div class="stat-icon danger">
                                <i class="fas fa-exclamation-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo $summary['paid']; ?></div>
                                <div class="stat-label">Paid Teachers</div>
                            </div>
                            <div class="stat-icon info">
                                <i class="fas fa-user-check"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><?php echo $editingSalary ? 'Update Salary Record' : 'Record Salary Payment'; ?></h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <?php if ($editingSalary && isset($editingSalary['id'])): ?>
                            <input type="hidden" name="salary_id" value="<?php echo $editingSalary['id']; ?>">
                        <?php endif; ?>
                        <input type="hidden" name="salary_month" value="<?php echo htmlspecialchars($selectedMonth); ?>">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Teacher *</label>
                                <select class="form-select" name="teacher_id" required>
                                    <option value="">Select Teacher</option>
                                    <?php foreach ($teachers as $teacher): ?>
                                        <option value="<?php echo $teacher['id']; ?>" <?php echo ($editingSalary['teacher_id'] ?? 0) == $teacher['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($teacher['full_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Amount *</label>
                                <input type="number" step="0.01" class="form-control" name="amount" value="<?php echo htmlspecialchars($editingSalary['amount'] ?? ''); ?>" placeholder="Total salary" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Paid Amount</label>
                                <input type="number" step="0.01" class="form-control" name="paid_amount" value="<?php echo htmlspecialchars($editingSalary['paid_amount'] ?? '0'); ?>">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Status *</label>
                                <select class="form-select" name="status" required>
                                    <?php foreach ($statusLabels as $key => $label): ?>
                                        <option value="<?php echo $key; ?>" <?php echo ($editingSalary['status'] ?? 'pending') === $key ? 'selected' : ''; ?>>
                                            <?php echo $label; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Notes</label>
                                <textarea class="form-control" name="notes" rows="2" placeholder="Optional notes regarding payment."><?php echo htmlspecialchars($editingSalary['notes'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> <?php echo $editingSalary ? 'Update Salary' : 'Save Salary'; ?>
                        </button>
                        <?php if ($editingSalary): ?>
                            <a href="salaries.php?month=<?php echo htmlspecialchars($selectedMonth); ?>" class="btn btn-secondary ms-2">Cancel</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Salary Overview (<?php echo $monthDate->format('F Y'); ?>)</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Teacher</th>
                                    <th>Base Salary</th>
                                    <th>Recorded Amount</th>
                                    <th>Paid</th>
                                    <th>Remaining</th>
                                    <th>Status</th>
                                    <th>Last Updated</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($teachers)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center">No teachers found.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($teachers as $teacher): ?>
                                        <?php
                                            $expected = $teacher['amount'] !== null ? $teacher['amount'] : (float)($teacher['salary'] ?? 0);
                                            $paid = $teacher['paid_amount'] !== null ? $teacher['paid_amount'] : 0;
                                            $remaining = max($expected - $paid, 0);
                                            $status = $teacher['status'] ?? 'pending';
                                        ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($teacher['full_name']); ?></td>
                                            <td>$<?php echo number_format($teacher['salary'] ?? 0, 2); ?></td>
                                            <td>$<?php echo number_format($expected, 2); ?></td>
                                            <td>$<?php echo number_format($paid, 2); ?></td>
                                            <td>$<?php echo number_format($remaining, 2); ?></td>
                                            <td>
                                                <span class="badge bg-<?php
                                                    echo $status === 'paid' ? 'success' : ($status === 'partial' ? 'warning' : 'danger');
                                                ?>">
                                                    <?php echo ucfirst($status); ?>
                                                </span>
                                            </td>
                                            <td><?php echo $teacher['updated_at'] ? formatDateTime($teacher['updated_at']) : 'N/A'; ?></td>
                                            <td>
                                                <?php if ($teacher['salary_id']): ?>
                                                    <a href="salaries.php?month=<?php echo htmlspecialchars($selectedMonth); ?>&edit=<?php echo $teacher['salary_id']; ?>" class="btn btn-sm btn-warning">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <?php if ($status !== 'paid'): ?>
                                                        <a href="salaries.php?month=<?php echo htmlspecialchars($selectedMonth); ?>&mark_paid=<?php echo $teacher['salary_id']; ?>" class="btn btn-sm btn-success" onclick="return confirm('Mark this salary as paid?');">
                                                            <i class="fas fa-check"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <a href="salaries.php?month=<?php echo htmlspecialchars($selectedMonth); ?>&delete=<?php echo $teacher['salary_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmDelete();">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                <?php else: ?>
                                                    <a href="#" class="btn btn-sm btn-warning disabled" tabindex="-1" aria-disabled="true">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>


