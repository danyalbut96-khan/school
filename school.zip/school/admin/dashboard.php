<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['admin']);

$pageTitle = "Admin Dashboard";
require_once '../includes/header.php';

// Get statistics
$stats = [];

// Total Students
$result = $db->query("SELECT COUNT(*) as count FROM students");
$stats['students'] = $result->fetch_assoc()['count'];

// Total Teachers
$result = $db->query("SELECT COUNT(*) as count FROM teachers");
$stats['teachers'] = $result->fetch_assoc()['count'];

// Total Classes
$result = $db->query("SELECT COUNT(*) as count FROM classes");
$stats['classes'] = $result->fetch_assoc()['count'];

// Total Subjects
$result = $db->query("SELECT COUNT(*) as count FROM subjects");
$stats['subjects'] = $result->fetch_assoc()['count'];

// Pending Fees
$result = $db->query("SELECT COUNT(*) as count FROM fees WHERE status = 'pending'");
$stats['pending_fees'] = $result->fetch_assoc()['count'];

// Recent Notices
$result = $db->query("SELECT * FROM notices ORDER BY created_at DESC LIMIT 5");
$recent_notices = [];
while ($row = $result->fetch_assoc()) {
    $recent_notices[] = $row;
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="students.php"><i class="fas fa-user-graduate"></i> Students</a></li>
                    <li><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Teachers</a></li>
                    <li><a href="classes.php"><i class="fas fa-school"></i> Classes</a></li>
                    <li><a href="subjects.php"><i class="fas fa-book"></i> Subjects</a></li>
                    <li><a href="examinations.php"><i class="fas fa-clipboard-list"></i> Examinations</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> Attendance</a></li>
                    <li><a href="fees.php"><i class="fas fa-money-bill-wave"></i> Fees</a></li>
                    <li><a href="notices.php"><i class="fas fa-bullhorn"></i> Notices</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <h2 class="mb-4">Dashboard Overview</h2>

            <!-- Statistics Cards -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo $stats['students']; ?></div>
                                <div class="stat-label">Total Students</div>
                            </div>
                            <div class="stat-icon primary">
                                <i class="fas fa-user-graduate"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo $stats['teachers']; ?></div>
                                <div class="stat-label">Total Teachers</div>
                            </div>
                            <div class="stat-icon success">
                                <i class="fas fa-chalkboard-teacher"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo $stats['classes']; ?></div>
                                <div class="stat-label">Classes</div>
                            </div>
                            <div class="stat-icon warning">
                                <i class="fas fa-school"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo $stats['pending_fees']; ?></div>
                                <div class="stat-label">Pending Fees</div>
                            </div>
                            <div class="stat-icon danger">
                                <i class="fas fa-money-bill-wave"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Notices -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-bullhorn"></i> Recent Notices</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($recent_notices)): ?>
                        <p class="text-muted">No notices yet.</p>
                    <?php else: ?>
                        <div class="list-group">
                            <?php foreach ($recent_notices as $notice): ?>
                                <div class="list-group-item">
                                    <h6><?php echo htmlspecialchars($notice['title']); ?></h6>
                                    <small class="text-muted"><?php echo formatDateTime($notice['created_at']); ?></small>
                                    <span class="badge bg-<?php echo $notice['priority'] == 'high' ? 'danger' : ($notice['priority'] == 'medium' ? 'warning' : 'info'); ?> float-end">
                                        <?php echo ucfirst($notice['priority']); ?>
                                    </span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <a href="notices.php" class="btn btn-primary mt-3">View All Notices</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

