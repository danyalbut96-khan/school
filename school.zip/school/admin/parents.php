<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['admin']);

$pageTitle = "Manage Parents";
$activePage = 'parents';
require_once '../includes/header.php';

// Fetch students for dropdown
$students = [];
$studentResult = $db->query("SELECT id, full_name, student_id FROM students ORDER BY full_name");
while ($row = $studentResult->fetch_assoc()) {
    $students[] = $row;
}

// Determine if we are editing a parent
$editingParent = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $parentResult = $db->query("SELECT p.*, u.username, u.email AS user_email FROM parents p JOIN users u ON p.user_id = u.id WHERE p.id = $editId");
    if ($parentResult && $parentResult->num_rows === 1) {
        $editingParent = $parentResult->fetch_assoc();
    } else {
        setFlashMessage('danger', 'Selected parent record was not found.');
        redirect('parents.php');
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $deleteId = (int)$_GET['delete'];
    $parent = $db->query("SELECT user_id FROM parents WHERE id = $deleteId")->fetch_assoc();
    if ($parent) {
        $db->query("DELETE FROM users WHERE id = {$parent['user_id']}");
        setFlashMessage('success', 'Parent deleted successfully.');
    } else {
        setFlashMessage('danger', 'Unable to locate the parent to delete.');
    }
    redirect('parents.php');
}

// Handle create/update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $parentId = isset($_POST['parent_id']) ? (int)$_POST['parent_id'] : 0;
    $fullNameRaw = sanitize($_POST['full_name'] ?? '');
    $emailRaw = sanitize($_POST['email'] ?? '');
    $phoneRaw = sanitize($_POST['phone'] ?? '');
    $addressRaw = sanitize($_POST['address'] ?? '');
    $relationRaw = sanitize($_POST['relation'] ?? 'Parent');
    $studentId = (int)($_POST['student_id'] ?? 0);
    $usernameRaw = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($fullNameRaw) || empty($usernameRaw) || empty($emailRaw) || !$studentId) {
        setFlashMessage('danger', 'Please fill in all required fields.');
        redirect('parents.php');
    }

    $fullName = $db->escape($fullNameRaw);
    $email = $db->escape($emailRaw);
    $phone = $db->escape($phoneRaw);
    $address = $db->escape($addressRaw);
    $relation = $db->escape($relationRaw);
    $username = $db->escape($usernameRaw);

    if ($parentId > 0) {
        // Update existing parent
        $parent = $db->query("SELECT p.id, p.user_id FROM parents p WHERE p.id = $parentId")->fetch_assoc();
        if (!$parent) {
            setFlashMessage('danger', 'Parent not found.');
            redirect('parents.php');
        }

        $userId = (int)$parent['user_id'];
        $check = $db->query("SELECT id FROM users WHERE (username = '$username' OR email = '$email') AND id != $userId");
        if ($check && $check->num_rows > 0) {
            setFlashMessage('danger', 'Username or email already in use by another user.');
            redirect('parents.php?edit=' . $parentId);
        }

        if (!empty($password)) {
            $hashedPassword = hashPassword($password);
            $db->query("UPDATE users SET username = '$username', email = '$email', password = '$hashedPassword' WHERE id = $userId");
        } else {
            $db->query("UPDATE users SET username = '$username', email = '$email' WHERE id = $userId");
        }

        $db->query("UPDATE parents SET full_name = '$fullName', email = '$email', phone = '$phone', address = '$address', student_id = $studentId, relation = '$relation' WHERE id = $parentId");

        setFlashMessage('success', 'Parent updated successfully.');
        redirect('parents.php');
    } else {
        // Create new parent
        if (empty($password)) {
            setFlashMessage('danger', 'Password is required when creating a new parent account.');
            redirect('parents.php');
        }

        $check = $db->query("SELECT id FROM users WHERE username = '$username' OR email = '$email'");
        if ($check && $check->num_rows > 0) {
            setFlashMessage('danger', 'Username or email already exists.');
            redirect('parents.php');
        }

        $hashedPassword = hashPassword($password);
        $db->query("INSERT INTO users (username, email, password, role) VALUES ('$username', '$email', '$hashedPassword', 'parent')");
        $userId = $db->lastInsertId();

        $db->query("INSERT INTO parents (user_id, full_name, email, phone, address, student_id, relation) VALUES ($userId, '$fullName', '$email', '$phone', '$address', $studentId, '$relation')");

        setFlashMessage('success', 'Parent added successfully.');
        redirect('parents.php');
    }
}

// Fetch parents list
$parents = [];
$parentList = $db->query("SELECT p.*, s.full_name AS student_name, s.student_id AS student_code FROM parents p JOIN students s ON p.student_id = s.id ORDER BY p.id DESC");
while ($row = $parentList->fetch_assoc()) {
    $parents[] = $row;
}

// Statistics
$totalParents = count($parents);
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <?php require '../includes/admin_sidebar.php'; ?>
        </div>

        <div class="col-md-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Manage Parents</h2>
                <?php if ($editingParent): ?>
                    <a href="parents.php" class="btn btn-secondary"><i class="fas fa-undo"></i> Cancel Edit</a>
                <?php endif; ?>
            </div>

            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number"><?php echo $totalParents; ?></div>
                                <div class="stat-label">Total Parents</div>
                            </div>
                            <div class="stat-icon primary">
                                <i class="fas fa-people-roof"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><?php echo $editingParent ? 'Edit Parent' : 'Add Parent'; ?></h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <?php if ($editingParent && isset($editingParent['id'])): ?>
                            <input type="hidden" name="parent_id" value="<?php echo $editingParent['id']; ?>">
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Full Name *</label>
                                <input type="text" class="form-control" name="full_name" value="<?php echo htmlspecialchars($editingParent['full_name'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Relation</label>
                                <input type="text" class="form-control" name="relation" value="<?php echo htmlspecialchars($editingParent['relation'] ?? 'Parent'); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Username *</label>
                                <input type="text" class="form-control" name="username" value="<?php echo htmlspecialchars($editingParent['username'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email *</label>
                                <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($editingParent['user_email'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Password <?php echo $editingParent ? '(leave blank to keep current)' : '*'; ?></label>
                                <input type="password" class="form-control" name="password" <?php echo $editingParent ? '' : 'required'; ?>>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone</label>
                                <input type="text" class="form-control" name="phone" value="<?php echo htmlspecialchars($editingParent['phone'] ?? ''); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Linked Student *</label>
                                <select class="form-select" name="student_id" required>
                                    <option value="">Select Student</option>
                                    <?php foreach ($students as $student): ?>
                                        <option value="<?php echo $student['id']; ?>" <?php echo ($editingParent['student_id'] ?? 0) == $student['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($student['full_name'] . ' (' . $student['student_id'] . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Address</label>
                                <textarea class="form-control" name="address" rows="2"><?php echo htmlspecialchars($editingParent['address'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> <?php echo $editingParent ? 'Update Parent' : 'Add Parent'; ?>
                        </button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Parent Directory</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Relation</th>
                                    <th>Student</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($parents)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">No parents found.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($parents as $parent): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($parent['full_name']); ?></td>
                                            <td><?php echo htmlspecialchars($parent['relation'] ?? 'Parent'); ?></td>
                                            <td>
                                                <?php echo htmlspecialchars($parent['student_name']); ?>
                                                <small class="text-muted d-block"><?php echo htmlspecialchars($parent['student_code']); ?></small>
                                            </td>
                                            <td><?php echo htmlspecialchars($parent['email'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($parent['phone'] ?? 'N/A'); ?></td>
                                            <td>
                                                <a href="parents.php?edit=<?php echo $parent['id']; ?>" class="btn btn-sm btn-warning">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <a href="parents.php?delete=<?php echo $parent['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmDelete();">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>


