<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['admin']);

$pageTitle = "Manage Classes";
require_once '../includes/header.php';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $db->query("DELETE FROM classes WHERE id = $id");
    setFlashMessage('success', 'Class deleted successfully');
    redirect('classes.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $class_name = sanitize($_POST['class_name']);
    $section = sanitize($_POST['section']);
    $capacity = (int)$_POST['capacity'];
    $class_teacher_id = !empty($_POST['class_teacher_id']) ? (int)$_POST['class_teacher_id'] : 'NULL';
    
    if (isset($_POST['edit_id'])) {
        $id = (int)$_POST['edit_id'];
        $db->query("UPDATE classes SET class_name = '$class_name', section = '$section', capacity = $capacity, class_teacher_id = $class_teacher_id WHERE id = $id");
        setFlashMessage('success', 'Class updated successfully');
    } else {
        $db->query("INSERT INTO classes (class_name, section, capacity, class_teacher_id) VALUES ('$class_name', '$section', $capacity, $class_teacher_id)");
        setFlashMessage('success', 'Class added successfully');
    }
    redirect('classes.php');
}

$result = $db->query("SELECT c.*, t.full_name as teacher_name FROM classes c LEFT JOIN teachers t ON c.class_teacher_id = t.id ORDER BY c.class_name");
$classes = [];
while ($row = $result->fetch_assoc()) {
    $classes[] = $row;
}

$teachers_result = $db->query("SELECT * FROM teachers ORDER BY full_name");
$teachers = [];
while ($row = $teachers_result->fetch_assoc()) {
    $teachers[] = $row;
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="students.php"><i class="fas fa-user-graduate"></i> Students</a></li>
                    <li><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Teachers</a></li>
                    <li><a href="classes.php" class="active"><i class="fas fa-school"></i> Classes</a></li>
                    <li><a href="subjects.php"><i class="fas fa-book"></i> Subjects</a></li>
                    <li><a href="examinations.php"><i class="fas fa-clipboard-list"></i> Examinations</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> Attendance</a></li>
                    <li><a href="fees.php"><i class="fas fa-money-bill-wave"></i> Fees</a></li>
                    <li><a href="notices.php"><i class="fas fa-bullhorn"></i> Notices</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Manage Classes</h2>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Add/Edit Class</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Class Name *</label>
                                <input type="text" class="form-control" name="class_name" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Section</label>
                                <input type="text" class="form-control" name="section" placeholder="A, B, C...">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Capacity</label>
                                <input type="number" class="form-control" name="capacity" value="30">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Class Teacher</label>
                                <select class="form-select" name="class_teacher_id">
                                    <option value="">Select Teacher</option>
                                    <?php foreach ($teachers as $teacher): ?>
                                        <option value="<?php echo $teacher['id']; ?>">
                                            <?php echo htmlspecialchars($teacher['full_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Add Class
                        </button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">All Classes</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Class Name</th>
                                    <th>Section</th>
                                    <th>Capacity</th>
                                    <th>Class Teacher</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($classes)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">No classes found</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($classes as $class): ?>
                                        <tr>
                                            <td><?php echo $class['id']; ?></td>
                                            <td><?php echo htmlspecialchars($class['class_name']); ?></td>
                                            <td><?php echo htmlspecialchars($class['section'] ?? 'N/A'); ?></td>
                                            <td><?php echo $class['capacity']; ?></td>
                                            <td><?php echo htmlspecialchars($class['teacher_name'] ?? 'Not Assigned'); ?></td>
                                            <td>
                                                <a href="?delete=<?php echo $class['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmDelete()">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

