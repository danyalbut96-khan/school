<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['admin']);

$pageTitle = "Manage Subjects";
require_once '../includes/header.php';

// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $db->query("DELETE FROM subjects WHERE id = $id");
    setFlashMessage('success', 'Subject deleted successfully.');
    redirect('subjects.php');
}

// Handle add subject
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject_name = sanitize($_POST['subject_name']);
    $subject_code = sanitize($_POST['subject_code']);
    $class_id = (int)$_POST['class_id'];
    $teacher_id = (int)$_POST['teacher_id'];

    if (empty($subject_name) || empty($class_id) || empty($teacher_id)) {
        setFlashMessage('danger', 'Please fill in all required fields.');
    } else {
        $db->query("INSERT INTO subjects (subject_name, subject_code, class_id, teacher_id) VALUES ('$subject_name', '$subject_code', $class_id, $teacher_id)");
        setFlashMessage('success', 'Subject added successfully.');
        redirect('subjects.php');
    }
}

// Fetch classes
$classes_result = $db->query("SELECT id, class_name, section FROM classes ORDER BY class_name");
$classes = [];
while ($row = $classes_result->fetch_assoc()) {
    $classes[] = $row;
}

// Fetch teachers
$teachers_result = $db->query("SELECT id, full_name FROM teachers ORDER BY full_name");
$teachers = [];
while ($row = $teachers_result->fetch_assoc()) {
    $teachers[] = $row;
}

// Fetch subjects list
$subjects_result = $db->query("SELECT sub.*, c.class_name, c.section, t.full_name as teacher_name FROM subjects sub
                                JOIN classes c ON sub.class_id = c.id
                                JOIN teachers t ON sub.teacher_id = t.id
                                ORDER BY c.class_name, sub.subject_name");
$subjects = [];
while ($row = $subjects_result->fetch_assoc()) {
    $subjects[] = $row;
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="students.php"><i class="fas fa-user-graduate"></i> Students</a></li>
                    <li><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Teachers</a></li>
                    <li><a href="classes.php"><i class="fas fa-school"></i> Classes</a></li>
                    <li><a href="subjects.php" class="active"><i class="fas fa-book"></i> Subjects</a></li>
                    <li><a href="examinations.php"><i class="fas fa-clipboard-list"></i> Examinations</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> Attendance</a></li>
                    <li><a href="fees.php"><i class="fas fa-money-bill-wave"></i> Fees</a></li>
                    <li><a href="notices.php"><i class="fas fa-bullhorn"></i> Notices</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Manage Subjects</h2>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Add Subject</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Subject Name *</label>
                                <input type="text" class="form-control" name="subject_name" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Subject Code</label>
                                <input type="text" class="form-control" name="subject_code" placeholder="e.g. MAT101">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Class *</label>
                                <select class="form-select" name="class_id" required>
                                    <option value="">Select Class</option>
                                    <?php foreach ($classes as $class): ?>
                                        <option value="<?php echo $class['id']; ?>">
                                            <?php echo htmlspecialchars($class['class_name'] . ' ' . ($class['section'] ?? '')); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Teacher *</label>
                                <select class="form-select" name="teacher_id" required>
                                    <option value="">Select Teacher</option>
                                    <?php foreach ($teachers as $teacher): ?>
                                        <option value="<?php echo $teacher['id']; ?>">
                                            <?php echo htmlspecialchars($teacher['full_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Add Subject
                        </button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">All Subjects</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Subject Name</th>
                                    <th>Code</th>
                                    <th>Class</th>
                                    <th>Teacher</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($subjects)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">No subjects found.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($subjects as $subject): ?>
                                        <tr>
                                            <td><?php echo $subject['id']; ?></td>
                                            <td><?php echo htmlspecialchars($subject['subject_name']); ?></td>
                                            <td><?php echo htmlspecialchars($subject['subject_code'] ?? 'N/A'); ?></td>
                                            <td><?php echo htmlspecialchars($subject['class_name'] . ' ' . ($subject['section'] ?? '')); ?></td>
                                            <td><?php echo htmlspecialchars($subject['teacher_name']); ?></td>
                                            <td>
                                                <a href="?delete=<?php echo $subject['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmDelete()">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
