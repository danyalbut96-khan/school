<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['admin']);

$pageTitle = "Add Student";
require_once '../includes/header.php';

// Get classes for dropdown
$classes_result = $db->query("SELECT * FROM classes ORDER BY class_name");
$classes = [];
while ($row = $classes_result->fetch_assoc()) {
    $classes[] = $row;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = sanitize($_POST['username']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $full_name = sanitize($_POST['full_name']);
    $student_id = sanitize($_POST['student_id']);
    $phone = sanitize($_POST['phone']);
    $address = sanitize($_POST['address']);
    $dob = $_POST['date_of_birth'];
    $gender = $_POST['gender'];
    $class_id = (int)$_POST['class_id'];
    $admission_date = $_POST['admission_date'];
    $parent_name = sanitize($_POST['parent_name']);
    $parent_phone = sanitize($_POST['parent_phone']);

    // Check if username/email exists
    $check = $db->query("SELECT id FROM users WHERE username = '$username' OR email = '$email'");
    if ($check->num_rows > 0) {
        setFlashMessage('danger', 'Username or email already exists');
    } else {
        // Create user account
        $hashed_password = hashPassword($password);
        $db->query("INSERT INTO users (username, email, password, role) VALUES ('$username', '$email', '$hashed_password', 'student')");
        $user_id = $db->lastInsertId();

        // Create student record
        $db->query("INSERT INTO students (user_id, full_name, student_id, email, phone, address, date_of_birth, gender, class_id, admission_date, parent_name, parent_phone) 
                    VALUES ($user_id, '$full_name', '$student_id', '$email', '$phone', '$address', '$dob', '$gender', $class_id, '$admission_date', '$parent_name', '$parent_phone')");

        setFlashMessage('success', 'Student added successfully');
        redirect('students.php');
    }
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="students.php" class="active"><i class="fas fa-user-graduate"></i> Students</a></li>
                    <li><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Teachers</a></li>
                    <li><a href="classes.php"><i class="fas fa-school"></i> Classes</a></li>
                    <li><a href="subjects.php"><i class="fas fa-book"></i> Subjects</a></li>
                    <li><a href="examinations.php"><i class="fas fa-clipboard-list"></i> Examinations</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> Attendance</a></li>
                    <li><a href="fees.php"><i class="fas fa-money-bill-wave"></i> Fees</a></li>
                    <li><a href="notices.php"><i class="fas fa-bullhorn"></i> Notices</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Add New Student</h2>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Student Information</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Username *</label>
                                <input type="text" class="form-control" name="username" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email *</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Password *</label>
                                <input type="password" class="form-control" name="password" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Student ID *</label>
                                <input type="text" class="form-control" name="student_id" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Full Name *</label>
                                <input type="text" class="form-control" name="full_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone</label>
                                <input type="text" class="form-control" name="phone">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Date of Birth</label>
                                <input type="date" class="form-control" name="date_of_birth">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Gender</label>
                                <select class="form-select" name="gender">
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Class *</label>
                                <select class="form-select" name="class_id" required>
                                    <option value="">Select Class</option>
                                    <?php foreach ($classes as $class): ?>
                                        <option value="<?php echo $class['id']; ?>">
                                            <?php echo htmlspecialchars($class['class_name'] . ' ' . ($class['section'] ?? '')); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Admission Date</label>
                                <input type="date" class="form-control" name="admission_date">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Parent Name</label>
                                <input type="text" class="form-control" name="parent_name">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Parent Phone</label>
                                <input type="text" class="form-control" name="parent_phone">
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Address</label>
                                <textarea class="form-control" name="address" rows="3"></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Add Student
                        </button>
                        <a href="students.php" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

