<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['admin']);

$pageTitle = "School Settings";
$activePage = 'settings';
require_once '../includes/header.php';

// Create uploads directory if it doesn't exist
$uploadDir = '../uploads/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Handle logo upload
if (isset($_POST['upload_logo'])) {
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['logo'];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $maxSize = 5 * 1024 * 1024; // 5MB
        
        if (!in_array($file['type'], $allowedTypes)) {
            setFlashMessage('danger', 'Invalid file type. Please upload JPG, PNG, GIF, or WebP images only.');
        } elseif ($file['size'] > $maxSize) {
            setFlashMessage('danger', 'File size exceeds 5MB limit.');
        } else {
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $fileName = 'school_logo_' . time() . '.' . $extension;
            $targetPath = $uploadDir . $fileName;
            
            if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                // Delete old logo if exists
                $oldLogo = $db->query("SELECT setting_value FROM school_settings WHERE setting_key = 'school_logo'")->fetch_assoc();
                if ($oldLogo && !empty($oldLogo['setting_value']) && file_exists('../' . $oldLogo['setting_value'])) {
                    unlink('../' . $oldLogo['setting_value']);
                }
                
                $logoPath = 'uploads/' . $fileName;
                $logoPathEscaped = $db->escape($logoPath);
                $checkLogo = $db->query("SELECT id FROM school_settings WHERE setting_key = 'school_logo' LIMIT 1");
                if ($checkLogo && $checkLogo->num_rows > 0) {
                    $db->query("UPDATE school_settings SET setting_value = '$logoPathEscaped' WHERE setting_key = 'school_logo'");
                } else {
                    $db->query("INSERT INTO school_settings (setting_key, setting_value) VALUES ('school_logo', '$logoPathEscaped')");
                }
                setFlashMessage('success', 'Logo uploaded successfully.');
            } else {
                setFlashMessage('danger', 'Failed to upload logo. Please try again.');
            }
        }
    } else {
        setFlashMessage('danger', 'No file uploaded or upload error occurred.');
    }
    redirect('settings.php');
}

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_settings'])) {
    $settings = [
        'school_name' => sanitize($_POST['school_name'] ?? ''),
        'school_address' => sanitize($_POST['school_address'] ?? ''),
        'school_phone' => sanitize($_POST['school_phone'] ?? ''),
        'school_email' => sanitize($_POST['school_email'] ?? ''),
        'school_website' => sanitize($_POST['school_website'] ?? ''),
        'school_motto' => sanitize($_POST['school_motto'] ?? ''),
        'school_description' => sanitize($_POST['school_description'] ?? ''),
    ];
    
    foreach ($settings as $key => $value) {
        $escapedKey = $db->escape($key);
        $escapedValue = $db->escape($value);
        $check = $db->query("SELECT id FROM school_settings WHERE setting_key = '$escapedKey' LIMIT 1");
        if ($check && $check->num_rows > 0) {
            $db->query("UPDATE school_settings SET setting_value = '$escapedValue' WHERE setting_key = '$escapedKey'");
        } else {
            $db->query("INSERT INTO school_settings (setting_key, setting_value) VALUES ('$escapedKey', '$escapedValue')");
        }
    }
    
    setFlashMessage('success', 'School settings updated successfully.');
    redirect('settings.php');
}

// Handle logo deletion
if (isset($_GET['delete_logo'])) {
    $logo = $db->query("SELECT setting_value FROM school_settings WHERE setting_key = 'school_logo'")->fetch_assoc();
    if ($logo && !empty($logo['setting_value'])) {
        $logoPath = '../' . $logo['setting_value'];
        if (file_exists($logoPath)) {
            unlink($logoPath);
        }
        $checkLogo = $db->query("SELECT id FROM school_settings WHERE setting_key = 'school_logo' LIMIT 1");
        if ($checkLogo && $checkLogo->num_rows > 0) {
            $db->query("UPDATE school_settings SET setting_value = '' WHERE setting_key = 'school_logo'");
        }
        setFlashMessage('success', 'Logo deleted successfully.');
    }
    redirect('settings.php');
}

// Fetch all settings
$settingsResult = $db->query("SELECT setting_key, setting_value FROM school_settings");
$schoolSettings = [];
while ($row = $settingsResult->fetch_assoc()) {
    $schoolSettings[$row['setting_key']] = $row['setting_value'];
}

// Set defaults if not exists
$defaults = [
    'school_name' => 'Smart School Management System',
    'school_address' => '',
    'school_phone' => '',
    'school_email' => '',
    'school_website' => '',
    'school_logo' => '',
    'school_motto' => '',
    'school_description' => '',
];

foreach ($defaults as $key => $defaultValue) {
    if (!isset($schoolSettings[$key])) {
        $schoolSettings[$key] = $defaultValue;
    }
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <?php require '../includes/admin_sidebar.php'; ?>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">School Settings</h2>

            <!-- Logo Upload Section -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-image"></i> School Logo</h5>
                </div>
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-4 text-center mb-3 mb-md-0">
                            <?php if (!empty($schoolSettings['school_logo']) && file_exists('../' . $schoolSettings['school_logo'])): ?>
                                <img src="../<?php echo htmlspecialchars($schoolSettings['school_logo']); ?>" 
                                     alt="School Logo" 
                                     class="img-fluid rounded shadow" 
                                     style="max-height: 200px; max-width: 100%;">
                                <div class="mt-2">
                                    <a href="?delete_logo=1" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete the logo?');">
                                        <i class="fas fa-trash"></i> Delete Logo
                                    </a>
                                </div>
                            <?php else: ?>
                                <div class="border rounded p-5 text-muted">
                                    <i class="fas fa-image fa-3x mb-3"></i>
                                    <p class="mb-0">No logo uploaded</p>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-8">
                            <form method="POST" action="" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label class="form-label">Upload New Logo</label>
                                    <input type="file" class="form-control" name="logo" accept="image/jpeg,image/png,image/gif,image/webp" required>
                                    <small class="text-muted">Accepted formats: JPG, PNG, GIF, WebP. Max size: 5MB</small>
                                </div>
                                <button type="submit" name="upload_logo" class="btn btn-primary">
                                    <i class="fas fa-upload"></i> Upload Logo
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- School Information Section -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-school"></i> School Information</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <input type="hidden" name="update_settings" value="1">
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label class="form-label">School Name *</label>
                                <input type="text" class="form-control" name="school_name" 
                                       value="<?php echo htmlspecialchars($schoolSettings['school_name']); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">School Address</label>
                                <textarea class="form-control" name="school_address" rows="2"><?php echo htmlspecialchars($schoolSettings['school_address']); ?></textarea>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">School Motto</label>
                                <input type="text" class="form-control" name="school_motto" 
                                       value="<?php echo htmlspecialchars($schoolSettings['school_motto']); ?>" 
                                       placeholder="e.g. Empowering Education Through Innovation">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone</label>
                                <input type="text" class="form-control" name="school_phone" 
                                       value="<?php echo htmlspecialchars($schoolSettings['school_phone']); ?>" 
                                       placeholder="+880 1234 567890">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="school_email" 
                                       value="<?php echo htmlspecialchars($schoolSettings['school_email']); ?>" 
                                       placeholder="info@school.com">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Website</label>
                                <input type="text" class="form-control" name="school_website" 
                                       value="<?php echo htmlspecialchars($schoolSettings['school_website']); ?>" 
                                       placeholder="www.school.com">
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Description</label>
                                <textarea class="form-control" name="school_description" rows="4" 
                                          placeholder="Brief description about the school..."><?php echo htmlspecialchars($schoolSettings['school_description']); ?></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Settings
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

