<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['admin']);

$pageTitle = "Manage Notices";
require_once '../includes/header.php';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $db->query("DELETE FROM notices WHERE id = $id");
    setFlashMessage('success', 'Notice deleted successfully');
    redirect('notices.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = sanitize($_POST['title']);
    $content = sanitize($_POST['content']);
    $target_audience = $_POST['target_audience'];
    $priority = $_POST['priority'];
    $created_by = $_SESSION['user_id'];
    
    if (isset($_POST['edit_id'])) {
        $id = (int)$_POST['edit_id'];
        $db->query("UPDATE notices SET title = '$title', content = '$content', target_audience = '$target_audience', priority = '$priority' WHERE id = $id");
        setFlashMessage('success', 'Notice updated successfully');
    } else {
        $db->query("INSERT INTO notices (title, content, target_audience, priority, created_by) VALUES ('$title', '$content', '$target_audience', '$priority', $created_by)");
        setFlashMessage('success', 'Notice added successfully');
    }
    redirect('notices.php');
}

$result = $db->query("SELECT n.*, u.username FROM notices n JOIN users u ON n.created_by = u.id ORDER BY n.created_at DESC");
$notices = [];
while ($row = $result->fetch_assoc()) {
    $notices[] = $row;
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="students.php"><i class="fas fa-user-graduate"></i> Students</a></li>
                    <li><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Teachers</a></li>
                    <li><a href="classes.php"><i class="fas fa-school"></i> Classes</a></li>
                    <li><a href="subjects.php"><i class="fas fa-book"></i> Subjects</a></li>
                    <li><a href="examinations.php"><i class="fas fa-clipboard-list"></i> Examinations</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> Attendance</a></li>
                    <li><a href="fees.php"><i class="fas fa-money-bill-wave"></i> Fees</a></li>
                    <li><a href="notices.php" class="active"><i class="fas fa-bullhorn"></i> Notices</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Manage Notices</h2>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Add New Notice</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="form-label">Title *</label>
                            <input type="text" class="form-control" name="title" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Content *</label>
                            <textarea class="form-control" name="content" rows="5" required></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Target Audience</label>
                                <select class="form-select" name="target_audience">
                                    <option value="all">All</option>
                                    <option value="students">Students</option>
                                    <option value="teachers">Teachers</option>
                                    <option value="parents">Parents</option>
                                    <option value="staff">Staff</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Priority</label>
                                <select class="form-select" name="priority">
                                    <option value="low">Low</option>
                                    <option value="medium" selected>Medium</option>
                                    <option value="high">High</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Add Notice
                        </button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">All Notices</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($notices)): ?>
                        <p class="text-muted">No notices found</p>
                    <?php else: ?>
                        <div class="list-group">
                            <?php foreach ($notices as $notice): ?>
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h5><?php echo htmlspecialchars($notice['title']); ?></h5>
                                            <p class="mb-1"><?php echo nl2br(htmlspecialchars($notice['content'])); ?></p>
                                            <small class="text-muted">
                                                Posted by <?php echo htmlspecialchars($notice['username']); ?> on <?php echo formatDateTime($notice['created_at']); ?>
                                                | Target: <?php echo ucfirst($notice['target_audience']); ?>
                                            </small>
                                        </div>
                                        <div>
                                            <span class="badge bg-<?php echo $notice['priority'] == 'high' ? 'danger' : ($notice['priority'] == 'medium' ? 'warning' : 'info'); ?>">
                                                <?php echo ucfirst($notice['priority']); ?>
                                            </span>
                                            <a href="?delete=<?php echo $notice['id']; ?>" class="btn btn-sm btn-danger mt-2" onclick="return confirmDelete()">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

