<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['admin']);

$pageTitle = "Manage Fees";
require_once '../includes/header.php';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $db->query("DELETE FROM fees WHERE id = $id");
    setFlashMessage('success', 'Fee record deleted successfully.');
    redirect('fees.php');
}

if (isset($_GET['mark_paid'])) {
    $id = (int)$_GET['mark_paid'];
    $fee = $db->query("SELECT amount FROM fees WHERE id = $id")->fetch_assoc();
    if ($fee) {
        $amount = $fee['amount'];
        $today = date('Y-m-d');
        $db->query("UPDATE fees SET status = 'paid', paid_amount = $amount, payment_date = '$today' WHERE id = $id");
        setFlashMessage('success', 'Fee marked as paid.');
    }
    redirect('fees.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = (int)$_POST['student_id'];
    $fee_type = sanitize($_POST['fee_type']);
    $amount = (float)$_POST['amount'];
    $due_date = $_POST['due_date'];
    $status = $_POST['status'];
    $remarks = sanitize($_POST['remarks']);

    if (!$student_id || empty($fee_type) || !$amount || empty($due_date)) {
        setFlashMessage('danger', 'Please fill in all required fields.');
    } else {
        $db->query("INSERT INTO fees (student_id, fee_type, amount, due_date, status, remarks)
                    VALUES ($student_id, '$fee_type', $amount, '$due_date', '$status', '$remarks')");
        setFlashMessage('success', 'Fee record added successfully.');
        redirect('fees.php');
    }
}

$students = [];
$student_result = $db->query("SELECT id, full_name, student_id FROM students ORDER BY full_name");
while ($row = $student_result->fetch_assoc()) {
    $students[] = $row;
}

$fees = [];
$fee_result = $db->query("SELECT f.*, s.full_name, s.student_id, c.class_name, c.section
                            FROM fees f
                            JOIN students s ON f.student_id = s.id
                            JOIN classes c ON s.class_id = c.id
                            ORDER BY f.due_date DESC");
while ($row = $fee_result->fetch_assoc()) {
    $fees[] = $row;
}

$total_due = 0;
$total_paid = 0;
foreach ($fees as $fee) {
    $total_due += $fee['amount'];
    $total_paid += $fee['paid_amount'];
}
$pending_balance = $total_due - $total_paid;
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="students.php"><i class="fas fa-user-graduate"></i> Students</a></li>
                    <li><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Teachers</a></li>
                    <li><a href="classes.php"><i class="fas fa-school"></i> Classes</a></li>
                    <li><a href="subjects.php"><i class="fas fa-book"></i> Subjects</a></li>
                    <li><a href="examinations.php"><i class="fas fa-clipboard-list"></i> Examinations</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> Attendance</a></li>
                    <li><a href="fees.php" class="active"><i class="fas fa-money-bill-wave"></i> Fees</a></li>
                    <li><a href="notices.php"><i class="fas fa-bullhorn"></i> Notices</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Manage Fees</h2>

            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number">$<?php echo number_format($total_due, 2); ?></div>
                                <div class="stat-label">Total Due</div>
                            </div>
                            <div class="stat-icon primary">
                                <i class="fas fa-dollar-sign"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number">$<?php echo number_format($total_paid, 2); ?></div>
                                <div class="stat-label">Total Paid</div>
                            </div>
                            <div class="stat-icon success">
                                <i class="fas fa-check-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="stat-number">$<?php echo number_format($pending_balance, 2); ?></div>
                                <div class="stat-label">Pending</div>
                            </div>
                            <div class="stat-icon danger">
                                <i class="fas fa-exclamation-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Add Fee Record</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Student *</label>
                                <select class="form-select" name="student_id" required>
                                    <option value="">Select Student</option>
                                    <?php foreach ($students as $student): ?>
                                        <option value="<?php echo $student['id']; ?>">
                                            <?php echo htmlspecialchars($student['full_name'] . ' (' . $student['student_id'] . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Fee Type *</label>
                                <input type="text" class="form-control" name="fee_type" placeholder="e.g. Tuition, Transport" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Amount *</label>
                                <input type="number" step="0.01" class="form-control" name="amount" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Due Date *</label>
                                <input type="date" class="form-control" name="due_date" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Status *</label>
                                <select class="form-select" name="status" required>
                                    <option value="pending">Pending</option>
                                    <option value="paid">Paid</option>
                                    <option value="partial">Partial</option>
                                </select>
                            </div>
                            <div class="col-12 mb-3">
                                <label class="form-label">Remarks</label>
                                <textarea class="form-control" name="remarks" rows="2" placeholder="Additional notes..."></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Add Fee
                        </button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Fee Records</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Class</th>
                                    <th>Fee Type</th>
                                    <th>Amount</th>
                                    <th>Due Date</th>
                                    <th>Status</th>
                                    <th>Paid Amount</th>
                                    <th>Payment Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($fees)): ?>
                                    <tr>
                                        <td colspan="9" class="text-center">No fee records found.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($fees as $fee): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($fee['full_name']); ?> <small class="text-muted">(<?php echo htmlspecialchars($fee['student_id']); ?>)</small></td>
                                            <td><?php echo htmlspecialchars($fee['class_name'] . ' ' . ($fee['section'] ?? '')); ?></td>
                                            <td><?php echo htmlspecialchars($fee['fee_type']); ?></td>
                                            <td>$<?php echo number_format($fee['amount'], 2); ?></td>
                                            <td><?php echo formatDate($fee['due_date']); ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $fee['status'] == 'paid' ? 'success' :
                                                        ($fee['status'] == 'partial' ? 'warning' : 'danger');
                                                ?>">
                                                    <?php echo ucfirst($fee['status']); ?>
                                                </span>
                                            </td>
                                            <td>$<?php echo number_format($fee['paid_amount'], 2); ?></td>
                                            <td><?php echo $fee['payment_date'] ? formatDate($fee['payment_date']) : 'N/A'; ?></td>
                                            <td>
                                                <?php if ($fee['status'] !== 'paid'): ?>
                                                    <a href="?mark_paid=<?php echo $fee['id']; ?>" class="btn btn-sm btn-success" onclick="return confirm('Mark this fee as paid?');">
                                                        <i class="fas fa-check"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <a href="?delete=<?php echo $fee['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmDelete();">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
