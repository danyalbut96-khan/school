<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['admin']);

$pageTitle = "Attendance Overview";
require_once '../includes/header.php';

$classes = [];
$class_result = $db->query("SELECT id, class_name, section FROM classes ORDER BY class_name");
while ($row = $class_result->fetch_assoc()) {
    $classes[] = $row;
}

$selected_class = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$selected_month = $_GET['month'] ?? date('Y-m');
$start_date = $selected_month . '-01';
$end_date = date('Y-m-t', strtotime($start_date));

$filters = "WHERE a.date BETWEEN '$start_date' AND '$end_date'";
if ($selected_class) {
    $filters .= " AND a.class_id = $selected_class";
}

$attendance_records = [];
$query = "SELECT a.*, s.full_name as student_name, s.student_id, c.class_name, c.section, sub.subject_name, t.full_name as teacher_name
          FROM attendance a
          JOIN students s ON a.student_id = s.id
          JOIN classes c ON a.class_id = c.id
          LEFT JOIN subjects sub ON a.subject_id = sub.id
          JOIN teachers t ON a.marked_by = t.id
          $filters
          ORDER BY a.date DESC, s.full_name";
$result = $db->query($query);
while ($row = $result->fetch_assoc()) {
    $attendance_records[] = $row;
}

// Summary statistics
$status_counts = ['present' => 0, 'absent' => 0, 'late' => 0, 'excused' => 0];
foreach ($attendance_records as $record) {
    $status = $record['status'];
    if (isset($status_counts[$status])) {
        $status_counts[$status]++;
    }
}
$total_records = array_sum($status_counts);
$attendance_rate = $total_records ? round(($status_counts['present'] / $total_records) * 100) : 0;
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="students.php"><i class="fas fa-user-graduate"></i> Students</a></li>
                    <li><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Teachers</a></li>
                    <li><a href="classes.php"><i class="fas fa-school"></i> Classes</a></li>
                    <li><a href="subjects.php"><i class="fas fa-book"></i> Subjects</a></li>
                    <li><a href="examinations.php"><i class="fas fa-clipboard-list"></i> Examinations</a></li>
                    <li><a href="attendance.php" class="active"><i class="fas fa-calendar-check"></i> Attendance</a></li>
                    <li><a href="fees.php"><i class="fas fa-money-bill-wave"></i> Fees</a></li>
                    <li><a href="notices.php"><i class="fas fa-bullhorn"></i> Notices</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Attendance Overview</h2>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Filters</h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="" class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Class</label>
                            <select class="form-select" name="class_id" onchange="this.form.submit()">
                                <option value="0">All Classes</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?php echo $class['id']; ?>" <?php echo $selected_class == $class['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($class['class_name'] . ' ' . ($class['section'] ?? '')); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Month</label>
                            <input type="month" class="form-control" name="month" value="<?php echo $selected_month; ?>" onchange="this.form.submit()">
                        </div>
                    </form>
                </div>
            </div>

            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="stat-card text-center">
                        <div class="stat-number text-primary"><?php echo $status_counts['present']; ?></div>
                        <div class="stat-label">Present</div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card text-center">
                        <div class="stat-number text-danger"><?php echo $status_counts['absent']; ?></div>
                        <div class="stat-label">Absent</div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card text-center">
                        <div class="stat-number text-warning"><?php echo $status_counts['late']; ?></div>
                        <div class="stat-label">Late</div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stat-card text-center">
                        <div class="stat-number"><?php echo $attendance_rate; ?>%</div>
                        <div class="stat-label">Attendance Rate</div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Attendance Records</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Student</th>
                                    <th>Class</th>
                                    <th>Subject</th>
                                    <th>Status</th>
                                    <th>Marked By</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($attendance_records)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No attendance records found.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($attendance_records as $record): ?>
                                        <tr>
                                            <td><?php echo formatDate($record['date']); ?></td>
                                            <td><?php echo htmlspecialchars($record['student_name']); ?> <small class="text-muted">(<?php echo htmlspecialchars($record['student_id']); ?>)</small></td>
                                            <td><?php echo htmlspecialchars($record['class_name'] . ' ' . ($record['section'] ?? '')); ?></td>
                                            <td><?php echo htmlspecialchars($record['subject_name'] ?? 'General'); ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $record['status'] == 'present' ? 'success' :
                                                        ($record['status'] == 'late' ? 'warning' :
                                                        ($record['status'] == 'excused' ? 'info' : 'danger'));
                                                ?>">
                                                    <?php echo ucfirst($record['status']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo htmlspecialchars($record['teacher_name']); ?></td>
                                            <td><?php echo htmlspecialchars($record['remarks'] ?? ''); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
