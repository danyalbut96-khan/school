<?php
require_once '../config/database.php';
require_once '../config/functions.php';

checkRole(['admin']);

$pageTitle = "Manage Examinations";
require_once '../includes/header.php';

// Delete examination
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $db->query("DELETE FROM examinations WHERE id = $id");
    setFlashMessage('success', 'Examination deleted successfully.');
    redirect('examinations.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $exam_name = sanitize($_POST['exam_name']);
    $exam_type = $_POST['exam_type'];
    $class_id = (int)$_POST['class_id'];
    $subject_id = (int)$_POST['subject_id'];
    $teacher_id = (int)$_POST['teacher_id'];
    $exam_date = $_POST['exam_date'];
    $total_marks = (float)($_POST['total_marks'] ?? 100);
    $passing_marks = (float)($_POST['passing_marks'] ?? 40);

    if (empty($exam_name) || empty($exam_type) || !$class_id || !$subject_id || !$teacher_id) {
        setFlashMessage('danger', 'Please fill in all required fields.');
    } else {
        $db->query("INSERT INTO examinations (exam_name, exam_type, class_id, subject_id, exam_date, total_marks, passing_marks, created_by)
                    VALUES ('$exam_name', '$exam_type', $class_id, $subject_id, '$exam_date', $total_marks, $passing_marks, $teacher_id)");
        setFlashMessage('success', 'Examination scheduled successfully.');
        redirect('examinations.php');
    }
}

// Fetch data for dropdowns
$classes = [];
$class_result = $db->query("SELECT id, class_name, section FROM classes ORDER BY class_name");
while ($row = $class_result->fetch_assoc()) {
    $classes[] = $row;
}

$subjects = [];
$subject_result = $db->query("SELECT sub.id, sub.subject_name, sub.subject_code, c.class_name, c.section FROM subjects sub JOIN classes c ON sub.class_id = c.id ORDER BY c.class_name, sub.subject_name");
while ($row = $subject_result->fetch_assoc()) {
    $subjects[] = $row;
}

$teachers = [];
$teacher_result = $db->query("SELECT id, full_name FROM teachers ORDER BY full_name");
while ($row = $teacher_result->fetch_assoc()) {
    $teachers[] = $row;
}

// List examinations
$exams = [];
$exam_result = $db->query("SELECT e.*, c.class_name, c.section, s.subject_name, t.full_name as teacher_name
                            FROM examinations e
                            JOIN classes c ON e.class_id = c.id
                            JOIN subjects s ON e.subject_id = s.id
                            JOIN teachers t ON e.created_by = t.id
                            ORDER BY e.exam_date DESC");
while ($row = $exam_result->fetch_assoc()) {
    $exams[] = $row;
}
?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                    <li><a href="students.php"><i class="fas fa-user-graduate"></i> Students</a></li>
                    <li><a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Teachers</a></li>
                    <li><a href="classes.php"><i class="fas fa-school"></i> Classes</a></li>
                    <li><a href="subjects.php"><i class="fas fa-book"></i> Subjects</a></li>
                    <li><a href="examinations.php" class="active"><i class="fas fa-clipboard-list"></i> Examinations</a></li>
                    <li><a href="attendance.php"><i class="fas fa-calendar-check"></i> Attendance</a></li>
                    <li><a href="fees.php"><i class="fas fa-money-bill-wave"></i> Fees</a></li>
                    <li><a href="notices.php"><i class="fas fa-bullhorn"></i> Notices</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Manage Examinations</h2>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Schedule New Examination</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Exam Name *</label>
                                <input type="text" class="form-control" name="exam_name" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Exam Type *</label>
                                <select class="form-select" name="exam_type" required>
                                    <option value="">Select Type</option>
                                    <option value="quiz">Quiz</option>
                                    <option value="midterm">Midterm</option>
                                    <option value="final">Final</option>
                                    <option value="assignment">Assignment</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Class *</label>
                                <select class="form-select" name="class_id" required>
                                    <option value="">Select Class</option>
                                    <?php foreach ($classes as $class): ?>
                                        <option value="<?php echo $class['id']; ?>">
                                            <?php echo htmlspecialchars($class['class_name'] . ' ' . ($class['section'] ?? '')); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Subject *</label>
                                <select class="form-select" name="subject_id" required>
                                    <option value="">Select Subject</option>
                                    <?php foreach ($subjects as $subject): ?>
                                        <option value="<?php echo $subject['id']; ?>">
                                            <?php echo htmlspecialchars($subject['class_name'] . ' - ' . $subject['subject_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Responsible Teacher *</label>
                                <select class="form-select" name="teacher_id" required>
                                    <option value="">Select Teacher</option>
                                    <?php foreach ($teachers as $teacher): ?>
                                        <option value="<?php echo $teacher['id']; ?>">
                                            <?php echo htmlspecialchars($teacher['full_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Exam Date</label>
                                <input type="date" class="form-control" name="exam_date" value="<?php echo date('Y-m-d'); ?>">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Total Marks</label>
                                <input type="number" step="0.1" class="form-control" name="total_marks" value="100">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Passing Marks</label>
                                <input type="number" step="0.1" class="form-control" name="passing_marks" value="40">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Schedule Examination
                        </button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Scheduled Examinations</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Exam</th>
                                    <th>Type</th>
                                    <th>Class</th>
                                    <th>Subject</th>
                                    <th>Teacher</th>
                                    <th>Date</th>
                                    <th>Total</th>
                                    <th>Passing</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($exams)): ?>
                                    <tr>
                                        <td colspan="9" class="text-center">No examinations scheduled.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($exams as $exam): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($exam['exam_name']); ?></td>
                                            <td><span class="badge bg-info text-dark"><?php echo ucfirst($exam['exam_type']); ?></span></td>
                                            <td><?php echo htmlspecialchars($exam['class_name'] . ' ' . ($exam['section'] ?? '')); ?></td>
                                            <td><?php echo htmlspecialchars($exam['subject_name']); ?></td>
                                            <td><?php echo htmlspecialchars($exam['teacher_name']); ?></td>
                                            <td><?php echo $exam['exam_date'] ? formatDate($exam['exam_date']) : 'TBD'; ?></td>
                                            <td><?php echo $exam['total_marks']; ?></td>
                                            <td><?php echo $exam['passing_marks']; ?></td>
                                            <td>
                                                <a href="?delete=<?php echo $exam['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmDelete()">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
