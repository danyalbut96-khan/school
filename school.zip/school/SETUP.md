# School Management System - Quick Setup Guide

## Quick Start (5 Minutes)

### For Local Development (XAMPP/WAMP)

1. **Extract Files**
   - Extract all files to `C:\xampp\htdocs\school-management`

2. **Create Database**
   - Open phpMyAdmin: `http://localhost/phpmyadmin`
   - Create database: `school_db`
   - Import `school_db.sql` file

3. **Configure Database**
   - Edit `config/database.php`
   - Set DB_USER = 'root' and DB_PASS = '' (default XAMPP)

4. **Create Uploads Folder**
   - Create folder: `school-management/uploads`
   - Set permissions: 755

5. **Access Application**
   - Open: `http://localhost/school-management`
   - Login: admin / admin123

### For cPanel/Hosting

1. **Upload Files**
   - Upload all files via FTP or cPanel File Manager
   - Upload to: `public_html/school-management` or your domain folder

2. **Create Database**
   - Go to cPanel → MySQL Databases
   - Create database: `school_db`
   - Create database user and assign privileges
   - Import `school_db.sql` via phpMyAdmin

3. **Configure Database**
   - Edit `config/database.php`
   - Update with your cPanel database credentials:
     ```php
     define('DB_HOST', 'localhost');
     define('DB_USER', 'cpanel_username_dbuser');
     define('DB_PASS', 'your_password');
     define('DB_NAME', 'cpanel_username_school_db');
     ```

4. **Set Permissions**
   - Create `uploads` folder
   - Set permissions: 755

5. **Access Application**
   - Visit: `http://yourdomain.com/school-management`
   - Login: admin / admin123

## Important Notes

- **Change default password** after first login!
- Ensure PHP version is 7.4 or higher
- Enable MySQLi extension in PHP
- Check file permissions for uploads folder

## Default Login

- **Username**: admin
- **Password**: admin123

## Need Help?

Check the full README.md for detailed documentation.

