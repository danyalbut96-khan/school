<?php
require_once 'config/database.php';
require_once 'config/functions.php';

session_start();
session_destroy();
redirect('login.php');

