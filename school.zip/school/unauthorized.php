<?php
require_once 'config/database.php';
require_once 'config/functions.php';

$pageTitle = "Unauthorized Access";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unauthorized - School Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6 text-center">
                <i class="fas fa-ban fa-5x text-danger mb-4"></i>
                <h1>Unauthorized Access</h1>
                <p class="lead">You don't have permission to access this page.</p>
                <a href="index.php" class="btn btn-primary">Go to Home</a>
            </div>
        </div>
    </div>
</body>
</html>

