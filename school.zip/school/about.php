<?php
require_once 'config/database.php';
require_once 'config/functions.php';

if (isLoggedIn()) {
    $role = $_SESSION['role'];
    redirect("$role/dashboard.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - <?php echo htmlspecialchars(getSchoolSetting('school_name', 'Smart School Management')); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            background-color: #f8fafc;
        }
        .about-hero {
            background: linear-gradient(135deg, rgba(30,64,175,0.88), rgba(59,130,246,0.88)), url('assets/images/school-banner.jpg') center/cover no-repeat;
            color: #fff;
            padding: 120px 0 100px;
        }
        .about-hero .breadcrumb a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
        }
        .value-card {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(15,23,42,0.12);
            padding: 26px;
            height: 100%;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .value-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 18px 40px rgba(15,23,42,0.18);
        }
        .timeline::before {
            content: '';
            position: absolute;
            left: 20px;
            top: 0;
            bottom: 0;
            width: 4px;
            background: linear-gradient(180deg, #2563eb, #38bdf8);
        }
        .timeline-item {
            position: relative;
            padding-left: 60px;
            margin-bottom: 40px;
        }
        .timeline-dot {
            position: absolute;
            left: 11px;
            top: 6px;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: #2563eb;
            border: 3px solid #ffffff;
            box-shadow: 0 0 0 4px rgba(37,99,235,0.15);
        }
        .dept-card {
            background: #fff;
            border-radius: 14px;
            padding: 24px;
            border: 1px solid rgba(37,99,235,0.08);
            height: 100%;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-semibold" href="index.php">
                <?php 
                $logo = getSchoolSetting('school_logo');
                if (!empty($logo) && file_exists(__DIR__ . '/' . $logo)): 
                ?>
                    <img src="<?php echo htmlspecialchars($logo); ?>" alt="Logo" style="height: 35px; margin-right: 10px; object-fit: contain;">
                <?php else: ?>
                    <i class="fas fa-graduation-cap me-2"></i>
                <?php endif; ?>
                <?php echo htmlspecialchars(getSchoolSetting('school_name', 'Smart School Management')); ?>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navMenu">
                <ul class="navbar-nav ms-auto align-items-lg-center">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php#contact">Contact</a>
                    </li>
                </ul>
                <div class="d-flex gap-2 ms-lg-3 mt-3 mt-lg-0">
                    <a href="admin_login.php" class="btn btn-light btn-sm"><i class="fas fa-user-shield me-1"></i>Admin</a>
                    <a href="teacher_login.php" class="btn btn-outline-light btn-sm"><i class="fas fa-chalkboard-teacher me-1"></i>Teacher</a>
                    <a href="student_login.php" class="btn btn-outline-light btn-sm"><i class="fas fa-user-graduate me-1"></i>Student</a>
                    <a href="parent_login.php" class="btn btn-outline-light btn-sm"><i class="fas fa-people-roof me-1"></i>Parent</a>
                </div>
            </div>
        </div>
    </nav>

    <section class="about-hero">
        <div class="container">
            <div class="row align-items-center g-4">
                <div class="col-lg-7">
                    <nav aria-label="breadcrumb" class="mb-3">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">About Us</li>
                        </ol>
                    </nav>
                    <h1 class="display-5 fw-bold"><?php echo htmlspecialchars(getSchoolSetting('school_name', 'Blue Horizon International School')); ?></h1>
                    <p class="lead"><?php echo htmlspecialchars(getSchoolSetting('school_description', 'For over two decades we have nurtured curious minds, empowered educators, and partnered with families to create an inclusive learning community.')); ?></p>
                    <div class="d-flex flex-wrap gap-3">
                        <div class="badge bg-light text-primary fs-6">8,500+ Alumni</div>
                        <div class="badge bg-light text-primary fs-6">7 Academic Departments</div>
                        <div class="badge bg-light text-primary fs-6">30+ Co-curricular Clubs</div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="value-card text-dark">
                        <h5 class="fw-semibold mb-3">Mission Statement</h5>
                        <p class="text-muted">To cultivate compassionate, agile, and globally-minded learners by blending rigorous academics with character education and community impact.</p>
                        <h5 class="fw-semibold mb-3">Vision 2030</h5>
                        <p class="text-muted mb-0">Harness technology and collaborative pedagogy to personalize learning pathways for every student across our regional campuses.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4">
                    <div class="value-card h-100">
                        <i class="fas fa-lightbulb text-primary fa-2x mb-3"></i>
                        <h5 class="fw-semibold mb-2">Academic Philosophy</h5>
                        <p class="text-muted mb-0">Inquiry-based, interdisciplinary learning experiences that develop critical thinking, creativity, and resilience.</p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="value-card h-100">
                        <i class="fas fa-users-gear text-primary fa-2x mb-3"></i>
                        <h5 class="fw-semibold mb-2">Leadership & Governance</h5>
                        <p class="text-muted mb-0">A council of academic deans, student representatives, and parent advisors steering curriculum design and wellbeing initiatives.</p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="value-card h-100">
                        <i class="fas fa-earth-asia text-primary fa-2x mb-3"></i>
                        <h5 class="fw-semibold mb-2">Global Partnerships</h5>
                        <p class="text-muted mb-0">Exchange programs with 12 partner schools across Asia and Europe expand our learners’ cultural intelligence.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-5 bg-white">
        <div class="container">
            <div class="row mb-4">
                <div class="col-lg-8">
                    <h2 class="fw-bold">Academic Departments & Learning Communities</h2>
                    <p class="text-muted">Each department is equipped with subject-specific dashboards inside Smart School to monitor curriculum maps, assessments, and student outcomes.</p>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-xl-4">
                    <div class="dept-card h-100">
                        <h5 class="fw-semibold">STEM Faculty</h5>
                        <p class="text-muted">Hands-on labs, robotics competitions, and advanced placement mathematics tracks guided by industry mentors.</p>
                    </div>
                </div>
                <div class="col-md-6 col-xl-4">
                    <div class="dept-card h-100">
                        <h5 class="fw-semibold">Humanities & Languages</h5>
                        <p class="text-muted">Research-based explorations across history, literature, and world languages anchored in debate and Model UN.</p>
                    </div>
                </div>
                <div class="col-md-6 col-xl-4">
                    <div class="dept-card h-100">
                        <h5 class="fw-semibold">Arts & Design</h5>
                        <p class="text-muted">Studios for visual arts, design thinking labs, theatre productions, and a digital media center.</p>
                    </div>
                </div>
                <div class="col-md-6 col-xl-4">
                    <div class="dept-card h-100">
                        <h5 class="fw-semibold">Business & Entrepreneurship</h5>
                        <p class="text-muted">A start-up incubator, financial literacy labs, and partnerships with local enterprises nurture future-ready leaders.</p>
                    </div>
                </div>
                <div class="col-md-6 col-xl-4">
                    <div class="dept-card h-100">
                        <h5 class="fw-semibold">Sports Science & Wellness</h5>
                        <p class="text-muted">Comprehensive athletics, sports analytics, and SEL programs promoting holistic wellbeing.</p>
                    </div>
                </div>
                <div class="col-md-6 col-xl-4">
                    <div class="dept-card h-100">
                        <h5 class="fw-semibold">Primary Foundations</h5>
                        <p class="text-muted">Play-based early learning environments focused on literacy, numeracy, and social-emotional skills.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-5 position-relative overflow-hidden">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <h2 class="fw-bold mb-4">Milestones in Our Journey</h2>
                    <div class="position-relative timeline">
                        <div class="timeline-item">
                            <span class="timeline-dot"></span>
                            <h6 class="fw-semibold">1998 — School Founded</h6>
                            <p class="text-muted mb-0">Blue Horizon opens with a mission to provide global education in Dhaka.</p>
                        </div>
                        <div class="timeline-item">
                            <span class="timeline-dot"></span>
                            <h6 class="fw-semibold">2008 — STEAM Integration</h6>
                            <p class="text-muted mb-0">Launch of integrated STEAM labs and international robotics competitions.</p>
                        </div>
                        <div class="timeline-item">
                            <span class="timeline-dot"></span>
                            <h6 class="fw-semibold">2016 — Smart School Platform</h6>
                            <p class="text-muted mb-0">Deployment of our unified management system connecting all stakeholders.</p>
                        </div>
                        <div class="timeline-item">
                            <span class="timeline-dot"></span>
                            <h6 class="fw-semibold">2023 — Regional Expansion</h6>
                            <p class="text-muted mb-0">Opening of two satellite campuses and introduction of hybrid learning pathways.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="value-card h-100">
                        <h5 class="fw-semibold mb-3">Community Impact</h5>
                        <ul class="list-unstyled text-muted">
                            <li class="mb-2"><i class="fas fa-star text-primary me-2"></i>98% university placement success for graduating cohorts</li>
                            <li class="mb-2"><i class="fas fa-hands-helping text-primary me-2"></i>12,000+ hours of student-led service annually</li>
                            <li class="mb-2"><i class="fas fa-seedling text-primary me-2"></i>Green campus initiative reducing energy use by 35%</li>
                            <li><i class="fas fa-medal text-primary me-2"></i>National recognition for inclusive education practices</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-5 bg-white">
        <div class="container">
            <div class="row align-items-center g-4">
                <div class="col-lg-7">
                    <h2 class="fw-bold">Partner With Us</h2>
                    <p class="text-muted mb-4">We collaborate with education boards, ed-tech innovators, and community leaders to expand opportunities for learners. Discover how Smart School can accelerate your transformation journey.</p>
                    <a href="index.php#contact" class="btn btn-primary btn-lg"><i class="fas fa-phone-volume me-2"></i>Discuss Your Campus Goals</a>
                </div>
                <div class="col-lg-5">
                    <img src="assets/images/dashboard-preview.png" class="img-fluid rounded-4 shadow" alt="Collaboration">
                </div>
            </div>
        </div>
    </section>

    <footer class="bg-primary text-white py-4">
        <div class="container text-center">
            <p class="mb-1">&copy; <?php echo date('Y'); ?> Smart School Management System. Crafted for modern education ecosystems.</p>
            <small class="text-white-50">Blue Horizon International School · Dhaka, Bangladesh</small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


